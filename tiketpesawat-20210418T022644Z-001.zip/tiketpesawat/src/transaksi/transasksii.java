/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transaksi;

import admin.koneksi;
import java.awt.Color;
import java.sql.Connection;
import javax.swing.JOptionPane;
import java.util.Locale;
import java.util.StringTokenizer;
import java.text.NumberFormat;
import java.util.Random;
import javax.swing.JFrame;


public class transasksii extends javax.swing.JFrame {

    public transasksii() {
        initComponents();
        setExtendedState(getExtendedState() | JFrame.MAXIMIZED_BOTH);
        setVisible(true);

        format_panel();

        c1.setVisible(false);
        c2.setVisible(false);
        c3.setVisible(false);
        c4.setVisible(false);
        c5.setVisible(false);
    }

    public StringTokenizer token;
    public String ganti = "";
    public long angka;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel15 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        harga2 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jCheckBox1 = new javax.swing.JCheckBox();
        jComboBox1 = new javax.swing.JComboBox<>();
        jCheckBox2 = new javax.swing.JCheckBox();
        jComboBox2 = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        maskapai = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        bandaraasal = new javax.swing.JLabel();
        kotaasal = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        kotatujuan = new javax.swing.JLabel();
        bandara_tujuan = new javax.swing.JLabel();
        tanggalberangkat = new javax.swing.JLabel();
        jamberangkat = new javax.swing.JLabel();
        tanggaltiba = new javax.swing.JLabel();
        jamtiba = new javax.swing.JLabel();
        kelas = new javax.swing.JLabel();
        harga = new javax.swing.JLabel();
        pilih1 = new javax.swing.JButton();
        jenis = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        hargatotal = new javax.swing.JLabel();
        pilih2 = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel10 = new javax.swing.JPanel();
        no_ktp_pemesan = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        nama_pemesan = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        panel_penumpang1 = new javax.swing.JPanel();
        no_ktp1 = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        nama1 = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        alamat1 = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        panel_penumpang2 = new javax.swing.JPanel();
        no_ktp2 = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        nama2 = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        alamat2 = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        panel_penumpang3 = new javax.swing.JPanel();
        no_ktp3 = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        nama3 = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        alamat3 = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        panel_penumpang4 = new javax.swing.JPanel();
        no_ktp4 = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        nama4 = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        alamat4 = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        panel_penumpang5 = new javax.swing.JPanel();
        no_ktp5 = new javax.swing.JTextField();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        nama5 = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        alamat5 = new javax.swing.JTextField();
        jLabel40 = new javax.swing.JLabel();
        panel_bayar = new javax.swing.JPanel();
        voucher = new javax.swing.JTextField();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        beli = new javax.swing.JButton();
        panel_bayar1 = new javax.swing.JPanel();
        bayar = new javax.swing.JTextField();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        beli1 = new javax.swing.JButton();
        jLabel46 = new javax.swing.JLabel();
        kembali = new javax.swing.JLabel();
        id_pesan = new javax.swing.JPanel();
        id_transaksi = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        btn_terakhir = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        tambah_pemesan1 = new javax.swing.JButton();
        tambah_penumpang1 = new javax.swing.JButton();
        tambah_penumpang2 = new javax.swing.JButton();
        tambah_penumpang3 = new javax.swing.JButton();
        tambah_penumpang4 = new javax.swing.JButton();
        tambah_penumpang5 = new javax.swing.JButton();
        jPanel13 = new javax.swing.JPanel();
        nama_pemesan_j = new javax.swing.JLabel();
        nama_penumpang1 = new javax.swing.JLabel();
        nama_penumpang2 = new javax.swing.JLabel();
        nama_penumpang3 = new javax.swing.JLabel();
        nama_penumpang4 = new javax.swing.JLabel();
        nama_penumpang5 = new javax.swing.JLabel();
        c0 = new javax.swing.JCheckBox();
        c1 = new javax.swing.JCheckBox();
        c2 = new javax.swing.JCheckBox();
        c3 = new javax.swing.JCheckBox();
        c4 = new javax.swing.JCheckBox();
        c5 = new javax.swing.JCheckBox();
        simpan = new javax.swing.JButton();
        jPanel14 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        bg = new javax.swing.JLabel();
        id_tiket = new javax.swing.JLabel();
        hartot = new javax.swing.JLabel();
        id_penerbangan = new javax.swing.JLabel();
        kapasitas = new javax.swing.JLabel();
        hit_harga = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 390, Short.MAX_VALUE)
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 480, 390, 30));

        jPanel7.setBackground(new java.awt.Color(51, 51, 51));

        jLabel14.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("anak-anak");

        harga2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        harga2.setForeground(new java.awt.Color(255, 255, 255));
        harga2.setText("   ");

        jLabel15.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("harga akan dikurangi sebanyak 30%");

        jLabel11.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Dengan harga satuan");

        jLabel16.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("dan untuk");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(harga2, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(39, 39, 39)
                        .addComponent(jLabel16))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel15)))
                .addGap(36, 36, 36))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(harga2)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 120, 390, 80));

        jLabel9.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Jumlah Kursi");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(34, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 20, 110, 100));

        jCheckBox1.setText("Dewasa");
        jCheckBox1.setName(" \n "); // NOI18N
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", " " }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        jComboBox1.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jComboBox1PropertyChange(evt);
            }
        });

        jCheckBox2.setText("Anak-Anak");
        jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox2ActionPerformed(evt);
            }
        });

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5" }));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });
        jComboBox2.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jComboBox2PropertyChange(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jCheckBox1)
                .addGap(45, 45, 45)
                .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jCheckBox2)
                .addContainerGap(68, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox1)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jCheckBox2)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(40, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 20, 390, 100));

        maskapai.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        maskapai.setText("Maskapai");

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));

        bandaraasal.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        bandaraasal.setForeground(new java.awt.Color(255, 255, 255));
        bandaraasal.setText("bandara asal");

        kotaasal.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        kotaasal.setText("Kota Asal");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(kotaasal, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(bandaraasal, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(58, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 13, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bandaraasal, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(kotaasal, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        kotatujuan.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        kotatujuan.setText("kota tujuan");

        bandara_tujuan.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        bandara_tujuan.setForeground(new java.awt.Color(255, 255, 255));
        bandara_tujuan.setText("bandara asal");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(kotatujuan, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(bandara_tujuan, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 12, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(kotatujuan, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bandara_tujuan, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        tanggalberangkat.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        tanggalberangkat.setText("tanggal berangkat");

        jamberangkat.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jamberangkat.setText("jam");

        tanggaltiba.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        tanggaltiba.setText("tanggal berangkat");

        jamtiba.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jamtiba.setText("jam");

        kelas.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        kelas.setText("kelas");

        harga.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        harga.setText("Harga");

        pilih1.setBackground(new java.awt.Color(255, 255, 255));
        pilih1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        pilih1.setText("Pilih Tiket");
        pilih1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pilih1ActionPerformed(evt);
            }
        });

        jenis.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jenis.setText("Maskapai");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(139, 139, 139)
                        .addComponent(jenis, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(harga)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(pilih1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(52, 52, 52))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(kelas)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(tanggaltiba)
                                    .addGap(18, 18, 18)
                                    .addComponent(jamtiba))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(tanggalberangkat)
                                        .addGap(18, 18, 18)
                                        .addComponent(jamberangkat))
                                    .addComponent(maskapai, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 242, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jenis)
                .addGap(23, 23, 23)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(maskapai, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tanggalberangkat)
                    .addComponent(jamberangkat))
                .addGap(39, 39, 39)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tanggaltiba)
                    .addComponent(jamtiba))
                .addGap(43, 43, 43)
                .addComponent(kelas)
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(harga)
                    .addComponent(pilih1))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 80, 460, 520));

        jLabel8.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Harga");

        jLabel6.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Kelas");

        jLabel5.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Tiba");

        jLabel3.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Berangkat");

        jLabel4.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Maskapai ");

        jLabel2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Kota Tujuan");

        jLabel1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Kota Asal");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(70, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(47, 47, 47)
                .addComponent(jLabel2)
                .addGap(59, 59, 59)
                .addComponent(jLabel4)
                .addGap(51, 51, 51)
                .addComponent(jLabel3)
                .addGap(40, 40, 40)
                .addComponent(jLabel5)
                .addGap(52, 52, 52)
                .addComponent(jLabel6)
                .addGap(36, 36, 36)
                .addComponent(jLabel8)
                .addGap(25, 25, 25))
        );

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 110, 520));

        hargatotal.setFont(new java.awt.Font("Segoe UI Semibold", 0, 24)); // NOI18N

        pilih2.setBackground(new java.awt.Color(255, 255, 255));
        pilih2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        pilih2.setText("Lanjut");
        pilih2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pilih2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(hargatotal, javax.swing.GroupLayout.DEFAULT_SIZE, 256, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pilih2)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(hargatotal, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(29, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pilih2)
                .addContainerGap())
        );

        getContentPane().add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 200, 390, 100));

        jPanel9.setBackground(new java.awt.Color(0, 0, 0));

        jLabel10.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Total");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 57, Short.MAX_VALUE)
                .addGap(31, 31, 31))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(113, Short.MAX_VALUE)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
        );

        getContentPane().add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 120, 110, 180));

        jTabbedPane1.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);

        jLabel17.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel17.setText("NIK");

        jLabel18.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel18.setText("PEMESAN");

        jLabel19.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel19.setText("Nama");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap(34, Short.MAX_VALUE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel19)
                    .addComponent(jLabel17))
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(nama_pemesan, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(no_ktp_pemesan, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24))
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(155, 155, 155)
                .addComponent(jLabel18)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(no_ktp_pemesan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nama_pemesan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(61, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab1", jPanel10);

        jLabel20.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel20.setText("NIK");

        jLabel21.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel21.setText("PENUMPANG");

        jLabel22.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel22.setText("Nama");

        jLabel24.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel24.setText("Alamat");

        javax.swing.GroupLayout panel_penumpang1Layout = new javax.swing.GroupLayout(panel_penumpang1);
        panel_penumpang1.setLayout(panel_penumpang1Layout);
        panel_penumpang1Layout.setHorizontalGroup(
            panel_penumpang1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_penumpang1Layout.createSequentialGroup()
                .addContainerGap(39, Short.MAX_VALUE)
                .addGroup(panel_penumpang1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang1Layout.createSequentialGroup()
                        .addComponent(jLabel21)
                        .addGap(144, 144, 144))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang1Layout.createSequentialGroup()
                        .addGroup(panel_penumpang1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(panel_penumpang1Layout.createSequentialGroup()
                                .addComponent(jLabel24)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(alamat1, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panel_penumpang1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang1Layout.createSequentialGroup()
                                    .addComponent(jLabel20)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(no_ktp1, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang1Layout.createSequentialGroup()
                                    .addComponent(jLabel22)
                                    .addGap(18, 18, 18)
                                    .addComponent(nama1, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(19, 19, 19))))
        );
        panel_penumpang1Layout.setVerticalGroup(
            panel_penumpang1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_penumpang1Layout.createSequentialGroup()
                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(panel_penumpang1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(no_ktp1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_penumpang1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nama1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_penumpang1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_penumpang1Layout.createSequentialGroup()
                        .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(alamat1, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE))
                .addGap(20, 20, 20))
        );

        jTabbedPane1.addTab("tab1", panel_penumpang1);

        jLabel25.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel25.setText("NIK");

        jLabel26.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel26.setText("PENUMPANG");

        jLabel27.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel27.setText("Nama");

        jLabel28.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel28.setText("Alamat");

        javax.swing.GroupLayout panel_penumpang2Layout = new javax.swing.GroupLayout(panel_penumpang2);
        panel_penumpang2.setLayout(panel_penumpang2Layout);
        panel_penumpang2Layout.setHorizontalGroup(
            panel_penumpang2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_penumpang2Layout.createSequentialGroup()
                .addContainerGap(46, Short.MAX_VALUE)
                .addGroup(panel_penumpang2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang2Layout.createSequentialGroup()
                        .addComponent(jLabel26)
                        .addGap(144, 144, 144))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang2Layout.createSequentialGroup()
                        .addGroup(panel_penumpang2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang2Layout.createSequentialGroup()
                                .addComponent(jLabel28)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(alamat2, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang2Layout.createSequentialGroup()
                                .addComponent(jLabel27)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(nama2, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang2Layout.createSequentialGroup()
                                .addComponent(jLabel25)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(no_ktp2, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(19, 19, 19))))
        );
        panel_penumpang2Layout.setVerticalGroup(
            panel_penumpang2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_penumpang2Layout.createSequentialGroup()
                .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(panel_penumpang2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(no_ktp2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_penumpang2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nama2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_penumpang2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_penumpang2Layout.createSequentialGroup()
                        .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(alamat2, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE))
                .addGap(20, 20, 20))
        );

        jTabbedPane1.addTab("tab1", panel_penumpang2);

        jLabel29.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel29.setText("NIK");

        jLabel30.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel30.setText("PENUMPANG");

        jLabel31.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel31.setText("Nama");

        jLabel32.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel32.setText("Alamat");

        javax.swing.GroupLayout panel_penumpang3Layout = new javax.swing.GroupLayout(panel_penumpang3);
        panel_penumpang3.setLayout(panel_penumpang3Layout);
        panel_penumpang3Layout.setHorizontalGroup(
            panel_penumpang3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_penumpang3Layout.createSequentialGroup()
                .addContainerGap(46, Short.MAX_VALUE)
                .addGroup(panel_penumpang3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang3Layout.createSequentialGroup()
                        .addComponent(jLabel30)
                        .addGap(144, 144, 144))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang3Layout.createSequentialGroup()
                        .addGroup(panel_penumpang3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang3Layout.createSequentialGroup()
                                .addComponent(jLabel32)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(alamat3, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang3Layout.createSequentialGroup()
                                .addComponent(jLabel31)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(nama3, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang3Layout.createSequentialGroup()
                                .addComponent(jLabel29)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(no_ktp3, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(19, 19, 19))))
        );
        panel_penumpang3Layout.setVerticalGroup(
            panel_penumpang3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_penumpang3Layout.createSequentialGroup()
                .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(panel_penumpang3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(no_ktp3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_penumpang3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nama3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_penumpang3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_penumpang3Layout.createSequentialGroup()
                        .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(alamat3, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE))
                .addGap(20, 20, 20))
        );

        jTabbedPane1.addTab("tab1", panel_penumpang3);

        jLabel33.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel33.setText("NIK");

        jLabel34.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel34.setText("PENUMPANG");

        jLabel35.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel35.setText("Nama");

        jLabel36.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel36.setText("Alamat");

        javax.swing.GroupLayout panel_penumpang4Layout = new javax.swing.GroupLayout(panel_penumpang4);
        panel_penumpang4.setLayout(panel_penumpang4Layout);
        panel_penumpang4Layout.setHorizontalGroup(
            panel_penumpang4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_penumpang4Layout.createSequentialGroup()
                .addContainerGap(46, Short.MAX_VALUE)
                .addGroup(panel_penumpang4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang4Layout.createSequentialGroup()
                        .addComponent(jLabel34)
                        .addGap(144, 144, 144))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang4Layout.createSequentialGroup()
                        .addGroup(panel_penumpang4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang4Layout.createSequentialGroup()
                                .addComponent(jLabel36)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(alamat4, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang4Layout.createSequentialGroup()
                                .addComponent(jLabel35)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(nama4, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang4Layout.createSequentialGroup()
                                .addComponent(jLabel33)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(no_ktp4, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(19, 19, 19))))
        );
        panel_penumpang4Layout.setVerticalGroup(
            panel_penumpang4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_penumpang4Layout.createSequentialGroup()
                .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(panel_penumpang4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(no_ktp4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_penumpang4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nama4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_penumpang4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_penumpang4Layout.createSequentialGroup()
                        .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(alamat4, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE))
                .addGap(20, 20, 20))
        );

        jTabbedPane1.addTab("tab1", panel_penumpang4);

        jLabel37.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel37.setText("NIK");

        jLabel38.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel38.setText("PENUMPANG");

        jLabel39.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel39.setText("Nama");

        jLabel40.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel40.setText("Alamat");

        javax.swing.GroupLayout panel_penumpang5Layout = new javax.swing.GroupLayout(panel_penumpang5);
        panel_penumpang5.setLayout(panel_penumpang5Layout);
        panel_penumpang5Layout.setHorizontalGroup(
            panel_penumpang5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_penumpang5Layout.createSequentialGroup()
                .addContainerGap(46, Short.MAX_VALUE)
                .addGroup(panel_penumpang5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang5Layout.createSequentialGroup()
                        .addComponent(jLabel38)
                        .addGap(144, 144, 144))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang5Layout.createSequentialGroup()
                        .addGroup(panel_penumpang5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang5Layout.createSequentialGroup()
                                .addComponent(jLabel40)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(alamat5, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang5Layout.createSequentialGroup()
                                .addComponent(jLabel39)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(nama5, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_penumpang5Layout.createSequentialGroup()
                                .addComponent(jLabel37)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(no_ktp5, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(19, 19, 19))))
        );
        panel_penumpang5Layout.setVerticalGroup(
            panel_penumpang5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_penumpang5Layout.createSequentialGroup()
                .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(panel_penumpang5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(no_ktp5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_penumpang5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nama5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_penumpang5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_penumpang5Layout.createSequentialGroup()
                        .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(alamat5, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE))
                .addGap(20, 20, 20))
        );

        jTabbedPane1.addTab("tab1", panel_penumpang5);

        jLabel41.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel41.setText("No Voucher");

        jLabel42.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel42.setText("Pembayaran");

        jLabel45.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel45.setText("Dapatkan kode voucher untuk pembayaran manual!");

        beli.setBackground(new java.awt.Color(255, 255, 255));
        beli.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        beli.setForeground(new java.awt.Color(255, 255, 255));
        beli.setText("Bayar");
        beli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beliActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel_bayarLayout = new javax.swing.GroupLayout(panel_bayar);
        panel_bayar.setLayout(panel_bayarLayout);
        panel_bayarLayout.setHorizontalGroup(
            panel_bayarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_bayarLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_bayarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_bayarLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(panel_bayarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_bayarLayout.createSequentialGroup()
                                .addComponent(jLabel42)
                                .addGap(144, 144, 144))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_bayarLayout.createSequentialGroup()
                                .addComponent(jLabel41)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(voucher, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(19, 19, 19))))
                    .addGroup(panel_bayarLayout.createSequentialGroup()
                        .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 341, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_bayarLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(beli, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        panel_bayarLayout.setVerticalGroup(
            panel_bayarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_bayarLayout.createSequentialGroup()
                .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(panel_bayarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(voucher, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addComponent(beli)
                .addContainerGap())
        );

        jTabbedPane1.addTab("tab1", panel_bayar);

        jLabel43.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel43.setText("Bayar");

        jLabel44.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel44.setText("Masukkan Nominal Uang Anda");

        beli1.setBackground(new java.awt.Color(255, 255, 255));
        beli1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        beli1.setForeground(new java.awt.Color(255, 255, 255));
        beli1.setText("Bayar");
        beli1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beli1ActionPerformed(evt);
            }
        });

        jLabel46.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel46.setText("Kembali");

        kembali.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        kembali.setText("Kembali");
        kembali.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembaliMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout panel_bayar1Layout = new javax.swing.GroupLayout(panel_bayar1);
        panel_bayar1.setLayout(panel_bayar1Layout);
        panel_bayar1Layout.setHorizontalGroup(
            panel_bayar1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_bayar1Layout.createSequentialGroup()
                .addGap(91, 91, 91)
                .addComponent(jLabel44)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_bayar1Layout.createSequentialGroup()
                .addContainerGap(39, Short.MAX_VALUE)
                .addGroup(panel_bayar1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(beli1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_bayar1Layout.createSequentialGroup()
                        .addGroup(panel_bayar1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_bayar1Layout.createSequentialGroup()
                                .addComponent(jLabel43)
                                .addGap(38, 38, 38))
                            .addGroup(panel_bayar1Layout.createSequentialGroup()
                                .addComponent(jLabel46)
                                .addGap(21, 21, 21)))
                        .addGroup(panel_bayar1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(bayar, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(kembali, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(61, 61, 61)))
                .addContainerGap())
        );
        panel_bayar1Layout.setVerticalGroup(
            panel_bayar1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_bayar1Layout.createSequentialGroup()
                .addGroup(panel_bayar1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panel_bayar1Layout.createSequentialGroup()
                        .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(bayar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(panel_bayar1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(kembali, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addComponent(beli1)
                .addContainerGap())
        );

        jTabbedPane1.addTab("tab1", panel_bayar1);

        id_transaksi.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        id_transaksi.setText("id_pesan");

        jLabel48.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel48.setText("Perhatian");

        jLabel49.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel49.setText("Pemesanan anda akan di simpan dengan kode  :");

        btn_terakhir.setBackground(new java.awt.Color(255, 255, 255));
        btn_terakhir.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        btn_terakhir.setForeground(new java.awt.Color(255, 255, 255));
        btn_terakhir.setText("Tampil Tiket");
        btn_terakhir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_terakhirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout id_pesanLayout = new javax.swing.GroupLayout(id_pesan);
        id_pesan.setLayout(id_pesanLayout);
        id_pesanLayout.setHorizontalGroup(
            id_pesanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(id_pesanLayout.createSequentialGroup()
                .addGap(149, 149, 149)
                .addComponent(jLabel48)
                .addContainerGap(177, Short.MAX_VALUE))
            .addGroup(id_pesanLayout.createSequentialGroup()
                .addGroup(id_pesanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(id_pesanLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 341, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(id_pesanLayout.createSequentialGroup()
                        .addGap(127, 127, 127)
                        .addComponent(id_transaksi, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, id_pesanLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btn_terakhir))
        );
        id_pesanLayout.setVerticalGroup(
            id_pesanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(id_pesanLayout.createSequentialGroup()
                .addComponent(jLabel48, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(id_transaksi)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                .addComponent(btn_terakhir)
                .addContainerGap())
        );

        jTabbedPane1.addTab("tab1", id_pesan);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 480, 390, 200));
        jTabbedPane1.getAccessibleContext().setAccessibleName("");

        jPanel11.setBackground(new java.awt.Color(0, 0, 0));
        jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tambah_pemesan1.setBackground(new java.awt.Color(255, 255, 255));
        tambah_pemesan1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tambah_pemesan1.setForeground(new java.awt.Color(255, 255, 255));
        tambah_pemesan1.setText("Tambah");
        tambah_pemesan1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambah_pemesan1ActionPerformed(evt);
            }
        });
        jPanel11.add(tambah_pemesan1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 92, -1));

        tambah_penumpang1.setBackground(new java.awt.Color(255, 255, 255));
        tambah_penumpang1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tambah_penumpang1.setForeground(new java.awt.Color(255, 255, 255));
        tambah_penumpang1.setText("Tambah");
        tambah_penumpang1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambah_penumpang1ActionPerformed(evt);
            }
        });
        jPanel11.add(tambah_penumpang1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 92, -1));

        tambah_penumpang2.setBackground(new java.awt.Color(255, 255, 255));
        tambah_penumpang2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tambah_penumpang2.setForeground(new java.awt.Color(255, 255, 255));
        tambah_penumpang2.setText("Tambah");
        tambah_penumpang2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambah_penumpang2ActionPerformed(evt);
            }
        });
        jPanel11.add(tambah_penumpang2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 92, -1));

        tambah_penumpang3.setBackground(new java.awt.Color(255, 255, 255));
        tambah_penumpang3.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tambah_penumpang3.setForeground(new java.awt.Color(255, 255, 255));
        tambah_penumpang3.setText("Tambah");
        tambah_penumpang3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambah_penumpang3ActionPerformed(evt);
            }
        });
        jPanel11.add(tambah_penumpang3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 92, -1));

        tambah_penumpang4.setBackground(new java.awt.Color(255, 255, 255));
        tambah_penumpang4.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tambah_penumpang4.setForeground(new java.awt.Color(255, 255, 255));
        tambah_penumpang4.setText("Tambah");
        tambah_penumpang4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambah_penumpang4ActionPerformed(evt);
            }
        });
        jPanel11.add(tambah_penumpang4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 92, -1));

        tambah_penumpang5.setBackground(new java.awt.Color(255, 255, 255));
        tambah_penumpang5.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tambah_penumpang5.setForeground(new java.awt.Color(255, 255, 255));
        tambah_penumpang5.setText("Tambah");
        tambah_penumpang5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambah_penumpang5ActionPerformed(evt);
            }
        });
        jPanel11.add(tambah_penumpang5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 92, -1));

        getContentPane().add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 480, 110, 200));

        nama_pemesan_j.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        nama_pemesan_j.setText("--Isi Nama Pemesan--");
        nama_pemesan_j.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nama_pemesan_jMouseClicked(evt);
            }
        });

        nama_penumpang1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        nama_penumpang1.setText("--Isi Nama Penumpang--");
        nama_penumpang1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nama_penumpang1MouseClicked(evt);
            }
        });

        nama_penumpang2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        nama_penumpang2.setText("--Isi Nama Penumpang--");
        nama_penumpang2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nama_penumpang2MouseClicked(evt);
            }
        });

        nama_penumpang3.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        nama_penumpang3.setText("--Isi Nama Penumpang--");
        nama_penumpang3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nama_penumpang3MouseClicked(evt);
            }
        });

        nama_penumpang4.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        nama_penumpang4.setText("--Isi Nama Penumpang--");
        nama_penumpang4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nama_penumpang4MouseClicked(evt);
            }
        });

        nama_penumpang5.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        nama_penumpang5.setText("--Isi Nama Penumpang--");
        nama_penumpang5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nama_penumpang5MouseClicked(evt);
            }
        });

        c0.setEnabled(false);
        c0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c0ActionPerformed(evt);
            }
        });

        c1.setEnabled(false);

        c2.setEnabled(false);

        c3.setEnabled(false);

        c4.setEnabled(false);

        c5.setEnabled(false);

        simpan.setBackground(new java.awt.Color(255, 255, 255));
        simpan.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        simpan.setForeground(new java.awt.Color(255, 255, 255));
        simpan.setText("Beli");
        simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                simpanActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addComponent(nama_penumpang3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(c3))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addComponent(nama_pemesan_j)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(c0))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nama_penumpang2)
                            .addComponent(nama_penumpang1))
                        .addGap(6, 6, 6)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(c1)
                            .addComponent(c2)))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addComponent(nama_penumpang5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(c5))
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addComponent(nama_penumpang4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(c4)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 111, Short.MAX_VALUE)
                        .addComponent(simpan, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(simpan)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nama_pemesan_j, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(c0))
                        .addGap(8, 8, 8)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addComponent(nama_penumpang1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(4, 4, 4)
                                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(nama_penumpang2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(c2)))
                            .addComponent(c1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nama_penumpang3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(c3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nama_penumpang4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(c4))
                        .addGap(2, 2, 2)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nama_penumpang5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(c5))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 310, 390, 160));

        jPanel14.setBackground(new java.awt.Color(0, 0, 0));

        jLabel12.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Pemesan");

        jLabel23.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("Penumpang");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel23)
                    .addComponent(jLabel12))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel23)
                .addContainerGap(103, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 310, 110, 160));

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/utama/home-page.png"))); // NOI18N
        jButton1.setBorder(null);
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 80, 60));

        bg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/utama/s.jpg"))); // NOI18N
        getContentPane().add(bg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1360, 780));

        id_tiket.setText("jLabel17");
        getContentPane().add(id_tiket, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 10, -1, -1));

        hartot.setText("jLabel47");
        getContentPane().add(hartot, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 670, -1, -1));

        id_penerbangan.setText("jLabel11");
        getContentPane().add(id_penerbangan, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 730, -1, -1));

        kapasitas.setText("jLabel47");
        getContentPane().add(kapasitas, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 650, -1, -1));

        hit_harga.setText("jLabel47");
        getContentPane().add(hit_harga, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 660, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void pilih1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pilih1ActionPerformed
        jPanel5.setVisible(true);
        jPanel6.setVisible(true);
    }//GEN-LAST:event_pilih1ActionPerformed

    void format_panel() {
        jPanel1.setBackground(new Color(255, 255, 255, 230));
        jPanel5.setBackground(new Color(255, 255, 255, 230));
        jPanel2.setBackground(new Color(0, 0, 0, 100));
        jPanel3.setBackground(new Color(0, 0, 0, 100));
        jPanel4.setBackground(new Color(0, 0, 0, 100));
        jPanel6.setBackground(new Color(0, 0, 0, 100));
        jPanel7.setVisible(false);
        jPanel6.setVisible(false);
        jPanel8.setVisible(false);
        jPanel9.setVisible(false);
        jPanel11.setBackground(new Color(0, 0, 0, 100));
        jPanel11.setVisible(false);
        jPanel13.setVisible(false);
        jPanel14.setVisible(false);
        jTabbedPane1.setVisible(false);
        jPanel15.setVisible(false);
        jPanel5.setVisible(false);
        jPanel7.setBackground(new Color(0, 0, 0, 100));
        jPanel14.setBackground(new Color(0, 0, 0, 100));
        jPanel15.setBackground(new Color(255,255,255,240));
        panel_penumpang1.setBackground(new Color(255,255,255,230));
        panel_penumpang2.setBackground(new Color(255,255,255,230));
        panel_penumpang3.setBackground(new Color(255,255,255,230));
        panel_penumpang4.setBackground(new Color(255,255,255,230));
        panel_penumpang5.setBackground(new Color(255,255,255,230));
        id_pesan.setBackground(new Color(255,255,255,230));
        btn_terakhir.setBackground(new Color(0,0,0,100));
        
        panel_bayar.setBackground(new Color(255, 255, 255, 230));
        panel_bayar1.setBackground(new Color(255, 255, 255, 230));

        
        
        jPanel8.setBackground(new Color(255, 255, 255, 230));
        jPanel9.setBackground(new Color(0, 0, 0, 100));
        jPanel10.setBackground(new Color(255, 255, 255, 230));
        jPanel13.setBackground(new Color(255, 255, 255, 230));
        jTabbedPane1.setBackground(new Color(0, 0, 0, 0));
        tambah_penumpang1.setBackground(new Color(0, 0, 0, 100));
        //penumpang
        
        nama_penumpang1.setVisible(false);
        nama_penumpang2.setVisible(false);
        nama_penumpang3.setVisible(false);
        nama_penumpang4.setVisible(false);
        nama_penumpang5.setVisible(false);

        tambah_penumpang1.setVisible(false);
        tambah_penumpang2.setVisible(false);
        tambah_penumpang3.setVisible(false);
        tambah_penumpang4.setVisible(false);
        tambah_penumpang5.setVisible(false);
        tambah_pemesan1.setVisible(false);

        tambah_penumpang1.setVisible(false);
        tambah_penumpang2.setVisible(false);
        tambah_penumpang3.setVisible(false);
        tambah_penumpang4.setVisible(false);
        tambah_penumpang5.setVisible(false);
        tambah_pemesan1.setVisible(false);
        
        beli1.setBackground(new Color(0, 0, 0, 100));
        beli.setBackground(new Color(0, 0, 0, 100));
        
        jTabbedPane1.setSelectedIndex(0);
        
        pilih1.setBackground(new Color(255,255,255,100));
      //  tambah_penumpang1.setBackground(new Color(0,0,0,100));
        tambah_penumpang1.setVisible(false);
        
    }

    void format() {
        
    }


    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        jCheckBox1.setSelected(true);
        String x = harga.getText();
        harga2.setText(x);
        jPanel7.setVisible(true);
        jPanel8.setVisible(true);
        jPanel9.setVisible(true);
        jumlah();
    }//GEN-LAST:event_jComboBox1ActionPerformed

    String a, b;

    int jumlahpenumpang;
    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        jCheckBox2.setSelected(true);
        a = jComboBox1.getSelectedItem().toString();
        b = jComboBox2.getSelectedItem().toString();

        int jmld = Integer.parseInt(a);
        int jmla = Integer.parseInt(b);

        String dataa1 = String.valueOf(jmld);
        String dataa2 = String.valueOf(jmla);


        int jml = jmld + jmla;

        
        if (jml >= 6) {
            JOptionPane.showMessageDialog(null, "Jumlah Maksimal Adalah 5 Kursi");

            jComboBox1.setSelectedIndex(0);
            jComboBox2.setSelectedIndex(0);
            jCheckBox1.setSelected(false);
            jCheckBox2.setSelected(false);
            jPanel7.setVisible(false);
            jPanel8.setVisible(false);
            jPanel9.setVisible(false);
        }else{
       jumlahpenumpang = jml;
       jumlah();
        }
    }//GEN-LAST:event_jComboBox2ActionPerformed

    int hargakel;

    public int getHargakel() {
        return hargakel;
    }

    public void setHargakel(int hargakel) {
        this.hargakel = hargakel;
    }


    void transaksi() {

        try {
            String sql1 = "select * from tiket where id_tiket  = '" + id_tiket.getText() + "'";
            java.sql.Connection conn1 = (Connection) koneksi.configDB();
            java.sql.Statement stm1 = conn1.createStatement();
            java.sql.ResultSet res1 = stm1.executeQuery(sql1);
            if (res1.next()) {
              
             String sisa = res1.getString("sisa_kursi");
             kapasitas.setText(sisa);
         String ja = jComboBox1.getSelectedItem().toString();
        String jb = jComboBox2.getSelectedItem().toString();

        
        int sasi = Integer.parseInt(sisa);
        int jmld = Integer.parseInt(ja);
        int jmla = Integer.parseInt(jb);

        if (!jCheckBox1.isSelected()){
        jmld = 0;
        }
        if(!jCheckBox2.isSelected()){
        jmla = 0;
        }
        
        int jmk = jmld + jmla;
             if(sasi < jmk){
        
                 JOptionPane.showMessageDialog(null, "Maaf, terjadi Kesalahan, tiket tersisa" + sasi);
        
        
                 pilih_tiket pt = new pilih_tiket();
        
                 this.dispose();
        }
            }else{
           // stok();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "GAGAL");

        }
    }

    void jumlah() {
        String h = hit_harga.getText();

        String jc1, jc2;
        jc1 = jComboBox1.getSelectedItem().toString();
        jc2 = jComboBox2.getSelectedItem().toString();

        int c11 = Integer.parseInt(jc1);
        int c21 = Integer.parseInt(jc2);

        int hargacon = Integer.parseInt(h);

        if (jCheckBox1.isSelected() && !jCheckBox2.isSelected()) {
            int jumlahDewasa = hargacon * c11;

            ganti = NumberFormat.getNumberInstance(Locale.US).format(jumlahDewasa);
            token = new StringTokenizer(ganti, ".");
            ganti = token.nextToken();
            ganti = ganti.replace(',', '.');
            
            
            String hart = String.valueOf(jumlahDewasa);
            hartot.setText(hart);
            hargatotal.setText("Rp. " + String.format(ganti));
        } else {

        }

        if (jCheckBox2.isSelected() && !jCheckBox1.isSelected()) {

            int ht = hargacon * c21;
            int diskon =  ht - (ht * 30 / 100);
            
            
            ganti = NumberFormat.getNumberInstance(Locale.US).format(diskon);
            token = new StringTokenizer(ganti, ".");
            ganti = token.nextToken();
            ganti = ganti.replace(',', '.');
            

            String hart = String.valueOf(diskon);
            hartot.setText(hart);
            hargatotal.setText("Rp. " + String.format(ganti));
            
        } else {

            System.out.println("tidak terselect 2 ");
        }
        if (jCheckBox1.isSelected() && jCheckBox2.isSelected()) {
            int jumlahDewasa = hargacon * c11;
            int ht = hargacon * c21;
            int diskon =  ht - (ht * 30 / 100);
            int total = jumlahDewasa + diskon;


            //angka = Integer.parseInt(harga.getText());
            ganti = NumberFormat.getNumberInstance(Locale.US).format(total);
            token = new StringTokenizer(ganti, ".");
            ganti = token.nextToken();
            ganti = ganti.replace(',', '.');
            

            String hart = String.valueOf(total);
            hartot.setText(hart);
            hargatotal.setText("Rp. " + String.format(ganti));
        }

    }

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        jPanel7.setVisible(true);
        jPanel8.setVisible(true);
        jPanel9.setVisible(true);
      jumlah();
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void jCheckBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox2ActionPerformed
        jPanel7.setVisible(true);
        jPanel8.setVisible(true);
        jPanel9.setVisible(true);
       jumlah();
    }//GEN-LAST:event_jCheckBox2ActionPerformed

    public int jmll;
    
    private void pilih2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pilih2ActionPerformed
transaksi();
        tambah_pemesan1.setVisible(true);
        
        String ja = jComboBox1.getSelectedItem().toString();
        String jb = jComboBox2.getSelectedItem().toString();

        int jmld = Integer.parseInt(ja);
        int jmla = Integer.parseInt(jb);

        String dataa1 = String.valueOf(jmld);
        String dataa2 = String.valueOf(jmla);

        if (!jCheckBox1.isSelected()){
        jmld = 0;
        }else if (!jCheckBox2.isSelected()){
        jmla = 0;
        }
        
        int jml = jmld + jmla;
        if(jml==1){
        nama_penumpang1.setVisible(true);
        c1.setVisible(true);
        }if(jml==2){
        nama_penumpang1.setVisible(true);
        nama_penumpang2.setVisible(true);
        c1.setVisible(true);
        c2.setVisible(true);
        }if(jml==3){   
        nama_penumpang1.setVisible(true);
        nama_penumpang2.setVisible(true);
        nama_penumpang3.setVisible(true);
        c1.setVisible(true);
        c2.setVisible(true);
        c3.setVisible(true);
        }if(jml==4){
        nama_penumpang1.setVisible(true);
        nama_penumpang2.setVisible(true);
        nama_penumpang3.setVisible(true);
        nama_penumpang4.setVisible(true);
        c1.setVisible(true);
        c2.setVisible(true);
        c3.setVisible(true);
        c4.setVisible(true);
        }if(jml==5){
        nama_penumpang1.setVisible(true);
        nama_penumpang2.setVisible(true);
        nama_penumpang3.setVisible(true);
        nama_penumpang4.setVisible(true);
        nama_penumpang5.setVisible(true);
        c1.setVisible(true);
        c2.setVisible(true);
        c3.setVisible(true);
        c4.setVisible(true);
        c5.setVisible(true);
        
        }
                
      
        jPanel11.setVisible(true);
        jPanel15.setVisible(true);
        jPanel13.setVisible(true);
        jPanel14.setVisible(true);
        jTabbedPane1.setVisible(true);
        
        tambah_pemesan1.setBackground(new Color(0,0,0,100));
        tambah_penumpang1.setBackground(new Color(0,0,0,100));
        tambah_penumpang2.setBackground(new Color(0,0,0,100));
        tambah_penumpang3.setBackground(new Color(0,0,0,100));
        tambah_penumpang4.setBackground(new Color(0,0,0,100));
        tambah_penumpang5.setBackground(new Color(0,0,0,100));
        simpan.setBackground(new Color(0,0,0,100));
    }//GEN-LAST:event_pilih2ActionPerformed

    private void tambah_penumpang1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambah_penumpang1ActionPerformed
        if (no_ktp1.getText().equalsIgnoreCase("")) //Jika Nilai Yang diambil pada TxtNama Kosong ("")
        {
            JOptionPane.showMessageDialog(null, "Lengkapi Semua data"); //Tampilkan Nilai Pada Comand Dialog
        } else if (nama1.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(null, "Lengkapi Semua data");
        } else if (alamat1.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(null, "Lengkapi Semua data");
        } else {
            try {
                String sql = "INSERT INTO penumpang VALUES ('" + no_ktp1.getText() + "','" + nama1.getText() + "','" + alamat1.getText() + "')";
                java.sql.Connection conn = (Connection) koneksi.configDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
                
                c1.setSelected(true);
                nama_penumpang1.setText(nama1.getText());
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
       
                        try {
                String sql = "INSERT INTO detail_pesan VALUES ('" + no_ktp_pemesan.getText() + "','" + no_ktp1.getText() + "')";
                java.sql.Connection conn = (Connection) koneksi.configDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
                
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
        }
        
        
        
    }//GEN-LAST:event_tambah_penumpang1ActionPerformed

    private void nama_penumpang1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nama_penumpang1MouseClicked
        jTabbedPane1.setSelectedIndex(1);
        tambah_penumpang1.setVisible(true);
        tambah_penumpang2.setVisible(false);
        tambah_penumpang3.setVisible(false);
        tambah_penumpang4.setVisible(false);
        tambah_penumpang5.setVisible(false);
        tambah_pemesan1.setVisible(false);
    }//GEN-LAST:event_nama_penumpang1MouseClicked

    private void nama_pemesan_jMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nama_pemesan_jMouseClicked
      jTabbedPane1.setSelectedIndex(0);
      tambah_penumpang1.setVisible(false);
      tambah_penumpang2.setVisible(false);
      tambah_penumpang3.setVisible(false);
      tambah_penumpang4.setVisible(false);
      tambah_penumpang5.setVisible(false);
      tambah_pemesan1.setVisible(true);
    }//GEN-LAST:event_nama_pemesan_jMouseClicked

    private void nama_penumpang2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nama_penumpang2MouseClicked
      jTabbedPane1.setSelectedIndex(2);
      tambah_penumpang1.setVisible(false);
        tambah_penumpang2.setVisible(true);
        tambah_penumpang3.setVisible(false);
        tambah_penumpang4.setVisible(false);
        tambah_penumpang5.setVisible(false);
        tambah_pemesan1.setVisible(false);
    }//GEN-LAST:event_nama_penumpang2MouseClicked

    private void nama_penumpang3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nama_penumpang3MouseClicked
       jTabbedPane1.setSelectedIndex(3);
       tambah_penumpang1.setVisible(false);
        tambah_penumpang2.setVisible(false);
        tambah_penumpang3.setVisible(true);
        tambah_penumpang4.setVisible(false);
        tambah_penumpang5.setVisible(false);
        tambah_pemesan1.setVisible(false);
    }//GEN-LAST:event_nama_penumpang3MouseClicked

    private void nama_penumpang4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nama_penumpang4MouseClicked
       jTabbedPane1.setSelectedIndex(4);
        tambah_penumpang1.setVisible(false);
        tambah_penumpang2.setVisible(false);
        tambah_penumpang3.setVisible(false);
        tambah_penumpang4.setVisible(true);
        tambah_penumpang5.setVisible(false);
        tambah_pemesan1.setVisible(false);
    }//GEN-LAST:event_nama_penumpang4MouseClicked

    private void nama_penumpang5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nama_penumpang5MouseClicked
      jTabbedPane1.setSelectedIndex(5);
           tambah_penumpang1.setVisible(false);
        tambah_penumpang2.setVisible(false);
        tambah_penumpang3.setVisible(false);
        tambah_penumpang4.setVisible(false);
        tambah_penumpang5.setVisible(true);
        tambah_pemesan1.setVisible(false);
    }//GEN-LAST:event_nama_penumpang5MouseClicked

    private void tambah_pemesan1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambah_pemesan1ActionPerformed
      if (no_ktp_pemesan.getText().equalsIgnoreCase("")) //Jika Nilai Yang diambil pada TxtNama Kosong ("")
        {
            JOptionPane.showMessageDialog(null, "Lengkapi Semua data"); //Tampilkan Nilai Pada Comand Dialog
        } else if (nama_pemesan.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(null, "Lengkapi Semua data");
        }else {
       
            try {
                String sql = "INSERT INTO pemesan VALUES ('" + no_ktp_pemesan.getText() + "','" + nama_pemesan.getText() + "')";
                java.sql.Connection conn = (Connection) koneksi.configDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
                
                c0.setSelected(true);
                nama_pemesan_j.setText(nama_pemesan.getText());
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
        }
    }//GEN-LAST:event_tambah_pemesan1ActionPerformed

    private void tambah_penumpang2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambah_penumpang2ActionPerformed
        // TODO add your handling code here:
                if (no_ktp2.getText().equalsIgnoreCase("")) //Jika Nilai Yang diambil pada TxtNama Kosong ("")
        {
            JOptionPane.showMessageDialog(null, "Lengkapi Semua data"); //Tampilkan Nilai Pada Comand Dialog
        } else if (nama2.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(null, "Lengkapi Semua data");
        } else if (alamat2.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(null, "Lengkapi Semua data");
        } else {
            try {
                String sql = "INSERT INTO penumpang VALUES ('" + no_ktp2.getText() + "','" + nama2.getText() + "','" + alamat2.getText() + "')";
                java.sql.Connection conn = (Connection) koneksi.configDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
                c2.setSelected(true);
                nama_penumpang2.setText(nama2.getText());
              //  JOptionPane.showMessageDialog(null, "Berhasil");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
       
            try {
                String sql = "INSERT INTO detail_pesan VALUES ('" + no_ktp_pemesan.getText() + "','" + no_ktp2.getText() + "')";
                java.sql.Connection conn = (Connection) koneksi.configDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
               // JOptionPane.showMessageDialog(null, "Berhasil");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
        }
    }//GEN-LAST:event_tambah_penumpang2ActionPerformed

    private void tambah_penumpang3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambah_penumpang3ActionPerformed
        // TODO add your handling code here:
                if (no_ktp3.getText().equalsIgnoreCase("")) //Jika Nilai Yang diambil pada TxtNama Kosong ("")
        {
            JOptionPane.showMessageDialog(null, "Lengkapi Semua data"); //Tampilkan Nilai Pada Comand Dialog
        } else if (nama3.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(null, "Lengkapi Semua data");
        } else if (alamat3.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(null, "Lengkapi Semua data");
        } else {
            try {
                String sql = "INSERT INTO penumpang VALUES ('" + no_ktp3.getText() + "','" + nama3.getText() + "','" + alamat3.getText() + "')";
                java.sql.Connection conn = (Connection) koneksi.configDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
                 c3.setSelected(true);
                 nama_penumpang3.setText(nama3.getText());
               // JOptionPane.showMessageDialog(null, "Berhasil");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
                   try {
                String sql = "INSERT INTO detail_pesan VALUES ('" + no_ktp_pemesan.getText() + "','" + no_ktp3.getText() + "')";
                java.sql.Connection conn = (Connection) koneksi.configDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
             //   JOptionPane.showMessageDialog(null, "Berhasil");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
           
        }
    }//GEN-LAST:event_tambah_penumpang3ActionPerformed

    private void tambah_penumpang4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambah_penumpang4ActionPerformed
        // TODO add your handling code here:
                        if (no_ktp4.getText().equalsIgnoreCase("")) //Jika Nilai Yang diambil pada TxtNama Kosong ("")
        {
            JOptionPane.showMessageDialog(null, "Lengkapi Semua data"); //Tampilkan Nilai Pada Comand Dialog
        } else if (nama4.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(null, "Lengkapi Semua data");
        } else if (alamat4.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(null, "Lengkapi Semua data");
        } else {
            try {
                String sql = "INSERT INTO penumpang VALUES ('" + no_ktp4.getText() + "','" + nama4.getText() + "','" + alamat4.getText() + "')";
                java.sql.Connection conn = (Connection) koneksi.configDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
                 c4.setSelected(true);
                 nama_penumpang4.setText(nama4.getText());
               // JOptionPane.showMessageDialog(null, "Berhasil");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
                        try {
                String sql = "INSERT INTO detail_pesan VALUES ('" + no_ktp_pemesan.getText() + "','" + no_ktp4.getText() + "')";
                java.sql.Connection conn = (Connection) koneksi.configDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
              //  JOptionPane.showMessageDialog(null, "Berhasil");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
        }
    }//GEN-LAST:event_tambah_penumpang4ActionPerformed

    private void tambah_penumpang5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambah_penumpang5ActionPerformed
        // TODO add your handling code here:
        if (no_ktp5.getText().equalsIgnoreCase("")) //Jika Nilai Yang diambil pada TxtNama Kosong ("")
        {
            JOptionPane.showMessageDialog(null, "Lengkapi Semua data"); //Tampilkan Nilai Pada Comand Dialog
        } else if (nama5.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(null, "Lengkapi Semua data");
        } else if (alamat5.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(null, "Lengkapi Semua data");
        } else {
            try {
                String sql = "INSERT INTO penumpang VALUES ('" + no_ktp5.getText() + "','" + nama5.getText() + "','" + alamat5.getText() + "')";
                java.sql.Connection conn = (Connection) koneksi.configDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
                c5.setSelected(true);
                nama_penumpang5.setText(nama5.getText());
              //  JOptionPane.showMessageDialog(null, "Berhasil");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
                        try {
                String sql = "INSERT INTO detail_pesan VALUES ('" + no_ktp_pemesan.getText() + "','" + no_ktp5.getText() + "')";
                java.sql.Connection conn = (Connection) koneksi.configDB();
                java.sql.PreparedStatement pst = conn.prepareStatement(sql);
                pst.execute();
              //  JOptionPane.showMessageDialog(null, "Berhasil");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
        }
    }//GEN-LAST:event_tambah_penumpang5ActionPerformed

    
    
    private void simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_simpanActionPerformed
    if(!c0.isSelected()){
    JOptionPane.showMessageDialog(null, "Data Pemesan tidak terisi");
    }
    if(!c1.isSelected()){
    JOptionPane.showMessageDialog(null, "Lengkapi Data");
           if(c2.isVisible()){
    if(!c2.isSelected()){
    JOptionPane.showMessageDialog(null, "Lengkapi Data");
    }
    }
    if(c3.isVisible()){
    if(!c3.isSelected()){
    JOptionPane.showMessageDialog(null, "Lengkapi Data");
    }
    }
    if(c4.isVisible()){
    if(!c4.isSelected()){
    JOptionPane.showMessageDialog(null, "Lengkapi Data");
    }
    }
    if(c5.isVisible()){
    if(!c5.isSelected()){
    JOptionPane.showMessageDialog(null, "Lengkapi Data");
    }
    }
        } else {
            jTabbedPane1.setSelectedIndex(7);
           jPanel11.setVisible(false);
        }

    
               
    }//GEN-LAST:event_simpanActionPerformed

        public void idotomatis(){
        String jadwal = "AK";
        Random acak = new Random();
        int a = 0;
        for (int i = 0; i < 1; i++) {
           a =  acak.nextInt(100000);
        }
        
        id_transaksi.setText(jadwal + a);
    }
    
    private void beliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beliActionPerformed
        // TODO add your handling code here:
        
        try {

            java.sql.Connection conn = (Connection) koneksi.configDB();
            String sql = "Select * from voucher where no_voucher like '%" + voucher.getText() + "%'";
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet res = stm.executeQuery(sql);
            if (res.next()) {
                
               JOptionPane.showMessageDialog(null, "Pembayaran Berhasil");
               id_transaksi.setBackground(new Color(255,255,255,230));
               jTabbedPane1.setSelectedIndex(8);
               idotomatis();
                }
             else {
                JOptionPane.showMessageDialog(null, "voucher salah");
            }
        } catch (Exception ex) {

            JOptionPane.showMessageDialog(null, "voucher salah");
        }
    }//GEN-LAST:event_beliActionPerformed

    private void beli1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beli1ActionPerformed
      String bayarr =bayar.getText();
       int intb = Integer.parseInt(bayarr);
       
       String kembalian = hartot.getText();
       int inth = Integer.parseInt(kembalian);
       
      
       
       if (intb < inth){
       JOptionPane.showMessageDialog(null, "Uang anda kurang");
       }else{
        int hasil = intb - inth;
        String a = String.valueOf(hasil);
        kembali.setText(a);
        
        jTabbedPane1.setSelectedIndex(6);
        tambah_penumpang1.setVisible(false);
        tambah_penumpang2.setVisible(false);
        tambah_penumpang3.setVisible(false);
        tambah_penumpang4.setVisible(false);
        tambah_penumpang5.setVisible(false);
        tambah_pemesan1.setVisible(false);
       }
    }//GEN-LAST:event_beli1ActionPerformed

    private void c0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c0ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_c0ActionPerformed

    private void kembaliMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembaliMouseClicked
      String bayarr =bayar.getText();
       int intb = Integer.parseInt(bayarr);
       
       String kembalian = hartot.getText();
       int inth = Integer.parseInt(kembalian);
       
      
       
       if (intb < inth){
       JOptionPane.showMessageDialog(null, "Uang anda kurang");
       }else{
        int hasil = intb - inth;
        String a = String.valueOf(hasil);
        kembali.setText(a);
        
       }
    }//GEN-LAST:event_kembaliMouseClicked



    private void btn_terakhirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_terakhirActionPerformed
    Tiket_tampil_user tk = new Tiket_tampil_user();
        
        tk.kotaasal.setText(kotaasal.getText());
        tk.kotatujuan.setText(kotatujuan.getText());
        tk.bandaraasal.setText(bandaraasal.getText());
        tk.bandara_tujuan.setText(bandara_tujuan.getText());
        tk.tanggalberangkat.setText(tanggalberangkat.getText());
        tk.tanggaltiba.setText(tanggaltiba.getText());
        tk.jamtiba.setText(jamtiba.getText());
        tk.jamberangkat.setText(jamberangkat.getText());
        tk.kelas.setText(kelas.getText());
        tk.harga.setText(hargatotal.getText());
        tk.id_tiket.setText(id_tiket.getText());
        tk.maskapai.setText(maskapai.getText());
        tk.no_penerbangan.setText(id_penerbangan.getText());
        tk.id_pesan.setText(id_transaksi.getText());
        
        if(c0.isVisible()){
        tk.nama_pemesan_j.setText(nama_pemesan_j.getText());
        }
        if(c1.isVisible()){
        tk.nama_penumpang1.setText(nama_penumpang1.getText());
        }
        if(c2.isVisible()){
        tk.nama_penumpang2.setText(nama_penumpang2.getText());
        }
        if(c3.isVisible()){
        tk.nama_penumpang3.setText(nama_penumpang3.getText());
        }
        if(c4.isVisible()){
        tk.nama_penumpang4.setText(nama_penumpang4.getText());
        }
        if(c5.isVisible()){
        tk.nama_penumpang5.setText(nama_penumpang5.getText());
        }
        
        
        String ja = jComboBox1.getSelectedItem().toString();
        String jb = jComboBox2.getSelectedItem().toString();

        
        
        int jmld = Integer.parseInt(ja);
        int jmla = Integer.parseInt(jb);

        if (!jCheckBox1.isSelected()){
        jmld = 0;
        }
        if(!jCheckBox2.isSelected()){
        jmla = 0;
        }
        
        String dataa1 = String.valueOf(jmld);
        String dataa2 = String.valueOf(jmla);

        int jmk = jmld + jmla;
        
        //kapasitas
        transaksi();
         String k = kapasitas.getText();
        int hitung = Integer.parseInt(k);
        int ab = hitung - jmk;
       
 
        int n = ab + 1;
        int m = ab + 2;
        int o = ab + 3;
        int p = ab + 4;
        int q = ab + 5;
        
        String r = String.valueOf(n);
        String s = String.valueOf(m);
        String t = String.valueOf(o);
        String u = String.valueOf(p);
        String v = String.valueOf(q);
        
        
                
        if (!jCheckBox1.isSelected()){
        jmld = 0;
        }else if (!jCheckBox2.isSelected()){
        jmla = 0;
        }
        
        int jml = jmld + jmla;
        if(jml==1){
        tk.nama_penumpang1.setVisible(true);
        tk.no_kursi.setText(r);
        }if(jml==2){
        tk.nama_penumpang1.setVisible(true);
        tk.nama_penumpang2.setVisible(true);
        tk.no_kursi.setText(r);
        tk.no_kursi2.setText(s);
        tk.no_kursi2.setVisible(true);
        }if(jml==3){   
        tk.nama_penumpang1.setVisible(true);
        tk.nama_penumpang2.setVisible(true);
        tk.nama_penumpang3.setVisible(true);
        tk.no_kursi.setText(r);
        tk.no_kursi2.setText(s);
        tk.no_kursi3.setText(t);
        
        tk.no_kursi2.setVisible(true);
        tk.no_kursi3.setVisible(true);
        }if(jml==4){
        tk.nama_penumpang1.setVisible(true);
        tk.nama_penumpang2.setVisible(true);
        tk.nama_penumpang3.setVisible(true);
        tk.nama_penumpang4.setVisible(true);
        tk.no_kursi.setText(r);
        tk.no_kursi2.setText(s);
        tk.no_kursi3.setText(t);
        tk.no_kursi2.setVisible(true);
        tk.no_kursi3.setVisible(true);
        tk.no_kursi4.setText(u);
        tk.no_kursi4.setVisible(true);
        }if(jml==5){
        tk.nama_penumpang1.setVisible(true);
        tk.nama_penumpang2.setVisible(true);
        tk.nama_penumpang3.setVisible(true);
        tk.nama_penumpang4.setVisible(true);
        tk.nama_penumpang5.setVisible(true);
        
        tk.no_kursi.setText(r);
        tk.no_kursi2.setText(s);
        tk.no_kursi3.setText(t);
        tk.no_kursi4.setText(u);
        tk.no_kursi5.setText(v);
        tk.no_kursi2.setVisible(true);
        tk.no_kursi3.setVisible(true);
        tk.no_kursi4.setVisible(true);
        tk.no_kursi5.setVisible(true);
        }
        
        
        try {
        String sql ="UPDATE tiket SET sisa_kursi =  '"+ab+"' WHERE id_tiket = '"+id_tiket.getText()+"'";
            java.sql.Connection conn=(Connection)koneksi.configDB();
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "data berhasil di edit");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Perubahan Data Gagal"+e.getMessage());
        }
        
        
            try {
            String sql = "INSERT INTO transaksi VALUES ('"+id_transaksi.getText()+"','"+no_ktp_pemesan.getText()+"','"+id_tiket.getText()+"')";
            java.sql.Connection conn=(Connection)koneksi.configDB();
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Berhasil");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_btn_terakhirActionPerformed

    private void jComboBox1PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jComboBox1PropertyChange
       
    }//GEN-LAST:event_jComboBox1PropertyChange

    private void jComboBox2PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jComboBox2PropertyChange
        
    }//GEN-LAST:event_jComboBox2PropertyChange

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        pilih_tiket pt = new pilih_tiket();
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed


    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(transasksii.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(transasksii.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(transasksii.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(transasksii.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new transasksii().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField alamat1;
    private javax.swing.JTextField alamat2;
    private javax.swing.JTextField alamat3;
    private javax.swing.JTextField alamat4;
    private javax.swing.JTextField alamat5;
    public javax.swing.JLabel bandara_tujuan;
    public javax.swing.JLabel bandaraasal;
    private javax.swing.JTextField bayar;
    private javax.swing.JButton beli;
    private javax.swing.JButton beli1;
    private javax.swing.JLabel bg;
    private javax.swing.JButton btn_terakhir;
    private javax.swing.JCheckBox c0;
    private javax.swing.JCheckBox c1;
    private javax.swing.JCheckBox c2;
    private javax.swing.JCheckBox c3;
    private javax.swing.JCheckBox c4;
    private javax.swing.JCheckBox c5;
    public javax.swing.JLabel harga;
    private javax.swing.JLabel harga2;
    private javax.swing.JLabel hargatotal;
    private javax.swing.JLabel hartot;
    public javax.swing.JLabel hit_harga;
    public javax.swing.JLabel id_penerbangan;
    private javax.swing.JPanel id_pesan;
    public javax.swing.JLabel id_tiket;
    private javax.swing.JLabel id_transaksi;
    private javax.swing.JButton jButton1;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JTabbedPane jTabbedPane1;
    public javax.swing.JLabel jamberangkat;
    public javax.swing.JLabel jamtiba;
    public javax.swing.JLabel jenis;
    private javax.swing.JLabel kapasitas;
    public javax.swing.JLabel kelas;
    private javax.swing.JLabel kembali;
    public javax.swing.JLabel kotaasal;
    public javax.swing.JLabel kotatujuan;
    public javax.swing.JLabel maskapai;
    private javax.swing.JTextField nama1;
    private javax.swing.JTextField nama2;
    private javax.swing.JTextField nama3;
    private javax.swing.JTextField nama4;
    private javax.swing.JTextField nama5;
    private javax.swing.JTextField nama_pemesan;
    private javax.swing.JLabel nama_pemesan_j;
    private javax.swing.JLabel nama_penumpang1;
    private javax.swing.JLabel nama_penumpang2;
    private javax.swing.JLabel nama_penumpang3;
    private javax.swing.JLabel nama_penumpang4;
    private javax.swing.JLabel nama_penumpang5;
    private javax.swing.JTextField no_ktp1;
    private javax.swing.JTextField no_ktp2;
    private javax.swing.JTextField no_ktp3;
    private javax.swing.JTextField no_ktp4;
    private javax.swing.JTextField no_ktp5;
    private javax.swing.JTextField no_ktp_pemesan;
    private javax.swing.JPanel panel_bayar;
    private javax.swing.JPanel panel_bayar1;
    private javax.swing.JPanel panel_penumpang1;
    private javax.swing.JPanel panel_penumpang2;
    private javax.swing.JPanel panel_penumpang3;
    private javax.swing.JPanel panel_penumpang4;
    private javax.swing.JPanel panel_penumpang5;
    private javax.swing.JButton pilih1;
    private javax.swing.JButton pilih2;
    private javax.swing.JButton simpan;
    private javax.swing.JButton tambah_pemesan1;
    private javax.swing.JButton tambah_penumpang1;
    private javax.swing.JButton tambah_penumpang2;
    private javax.swing.JButton tambah_penumpang3;
    private javax.swing.JButton tambah_penumpang4;
    private javax.swing.JButton tambah_penumpang5;
    public javax.swing.JLabel tanggalberangkat;
    public javax.swing.JLabel tanggaltiba;
    private javax.swing.JTextField voucher;
    // End of variables declaration//GEN-END:variables
}
