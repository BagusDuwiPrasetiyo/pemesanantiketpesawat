/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tambah_tiket;

import admin.koneksi;
import com.sun.corba.se.impl.orbutil.ORBConstants;
import data_.semuaData;
import java.awt.Color;
import java.awt.color.ColorSpace;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.util.Locale;
import java.util.StringTokenizer;
import java.text.NumberFormat;
import java.util.Set;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import tambah_data.tiket_pesawat;

/**
 *
 * @author LOrd
 */
public class tiket_ extends javax.swing.JFrame {

    public StringTokenizer token;
    public String ganti = "";
    public long angka;

    public tiket_() {
        initComponents();
        setExtendedState(getExtendedState() | JFrame.MAXIMIZED_BOTH);
        setVisible(true);
        jPanel2.setBackground(new Color(255, 255, 255, 230));
        panel_jumlah.setBackground(new Color(255, 255, 255, 230));
        jPanel3.setBackground(new Color(255, 255, 255, 230));
        idotomatis();
        jPanel2.setVisible(false);
        jPanel3.setVisible(false);
        panel_jumlah.setVisible(false);
        desain();
        jTabbedPane1.setSelectedIndex(0);
    }
    
    void desain(){
    jPanel1.setBackground(new Color(0,0,0,100));
    jPanel4.setBackground(new Color(0,0,0,50));
    jPanel5.setBackground(new Color(0,0,0,50));
    jTable1.setBackground(new Color(0,0,0,200));
    jTable2.setBackground(new Color(0,0,0,200));
    jTable3.setBackground(new Color(0,0,0,200));
    panel_pesawat.setBackground(new Color(255,255,255,230));
    panel_pesawat_tab.setBackground(new Color(0,0,0,100));
   // top.setBackground(new Color(0,0,0,180));
    load_table1();
    load_table2();
    load_table3();
    jPanel6.setBackground(new Color(0,0,0,100));
     jTabbedPane1.setBackground(new Color(0,0,0,0));
    pilih_data.setBackground(new Color(0,0,0,100));
    panel_pesawat_tab.setVisible(false);
// lebarKolom1();lebarKolom2();
 pilih_penerbangan.setBackground(new Color(255,255,255,230));
 
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        pilih_penerbangan = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        tab8 = new javax.swing.JLabel();
        tab9 = new javax.swing.JLabel();
        tab10 = new javax.swing.JLabel();
        set_idmesin = new javax.swing.JLabel();
        set_idpenerbangan = new javax.swing.JLabel();
        set_idjadwal = new javax.swing.JLabel();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jCheckBox3 = new javax.swing.JCheckBox();
        panel_pesawat = new javax.swing.JPanel();
        maskapai = new javax.swing.JLabel();
        kelas = new javax.swing.JLabel();
        jenis = new javax.swing.JLabel();
        pesawat = new javax.swing.JLabel();
        tgl_ber = new javax.swing.JLabel();
        jam_ber = new javax.swing.JLabel();
        tgl_tiba = new javax.swing.JLabel();
        jam_tiba = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        bandara_asal = new javax.swing.JLabel();
        kota_asal = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        kota_tujuan = new javax.swing.JLabel();
        bandara_tujuan = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        pilih_data = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        Hargato = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        tiketo = new javax.swing.JLabel();
        panel_pesawat_tab = new javax.swing.JPanel();
        tab11 = new javax.swing.JLabel();
        tab12 = new javax.swing.JLabel();
        tab13 = new javax.swing.JLabel();
        tab14 = new javax.swing.JLabel();
        tab15 = new javax.swing.JLabel();
        tab16 = new javax.swing.JLabel();
        tab17 = new javax.swing.JLabel();
        tab18 = new javax.swing.JLabel();
        panel_jumlah = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jumlah_kursi = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        Login6 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTabbedPane1.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        jTabbedPane1.setEnabled(false);
        jTabbedPane1.setVerifyInputWhenFocusTarget(false);

        jTable1.setForeground(new java.awt.Color(255, 255, 255));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.setEnabled(false);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jTable2.setForeground(new java.awt.Color(255, 255, 255));
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable2.setEnabled(false);
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable2);

        jTable3.setForeground(new java.awt.Color(255, 255, 255));
        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable3.setEnabled(false);
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable3);

        tab8.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        tab8.setText("ID Penerbangan    :");

        tab9.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        tab9.setText("ID Mesin                :");

        tab10.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        tab10.setText("ID Jadwal               :");

        set_idmesin.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N

        set_idpenerbangan.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N

        set_idjadwal.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N

        jCheckBox1.setBorderPaintedFlat(true);
        jCheckBox1.setEnabled(false);

        jCheckBox2.setBorderPaintedFlat(true);
        jCheckBox2.setEnabled(false);

        jCheckBox3.setBorderPaintedFlat(true);
        jCheckBox3.setEnabled(false);

        javax.swing.GroupLayout pilih_penerbanganLayout = new javax.swing.GroupLayout(pilih_penerbangan);
        pilih_penerbangan.setLayout(pilih_penerbanganLayout);
        pilih_penerbanganLayout.setHorizontalGroup(
            pilih_penerbanganLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pilih_penerbanganLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pilih_penerbanganLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pilih_penerbanganLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(pilih_penerbanganLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tab8)
                            .addComponent(tab10))
                        .addGap(18, 18, 18)
                        .addGroup(pilih_penerbanganLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pilih_penerbanganLayout.createSequentialGroup()
                                .addComponent(set_idjadwal)
                                .addGap(18, 18, 18)
                                .addComponent(jCheckBox3))
                            .addGroup(pilih_penerbanganLayout.createSequentialGroup()
                                .addComponent(set_idpenerbangan)
                                .addGap(18, 18, 18)
                                .addComponent(jCheckBox2))
                            .addGroup(pilih_penerbanganLayout.createSequentialGroup()
                                .addComponent(set_idmesin, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jCheckBox1)))
                        .addGap(0, 181, Short.MAX_VALUE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(pilih_penerbanganLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pilih_penerbanganLayout.createSequentialGroup()
                    .addGap(20, 20, 20)
                    .addComponent(tab9)
                    .addContainerGap(347, Short.MAX_VALUE)))
        );

        pilih_penerbanganLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {set_idjadwal, set_idmesin, set_idpenerbangan});

        pilih_penerbanganLayout.setVerticalGroup(
            pilih_penerbanganLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pilih_penerbanganLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pilih_penerbanganLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox1)
                    .addComponent(set_idmesin, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pilih_penerbanganLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pilih_penerbanganLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tab8)
                        .addComponent(set_idpenerbangan))
                    .addComponent(jCheckBox2))
                .addGap(18, 18, 18)
                .addGroup(pilih_penerbanganLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pilih_penerbanganLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tab10)
                        .addComponent(set_idjadwal))
                    .addComponent(jCheckBox3))
                .addContainerGap(35, Short.MAX_VALUE))
            .addGroup(pilih_penerbanganLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pilih_penerbanganLayout.createSequentialGroup()
                    .addContainerGap(331, Short.MAX_VALUE)
                    .addComponent(tab9)
                    .addGap(116, 116, 116)))
        );

        pilih_penerbanganLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {set_idjadwal, set_idmesin, set_idpenerbangan});

        jTabbedPane1.addTab("", pilih_penerbangan);

        maskapai.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        maskapai.setText("maskapai");

        kelas.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        kelas.setText("kelas");

        jenis.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jenis.setText("Jenis");

        pesawat.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        pesawat.setText("Pesawat");

        tgl_ber.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        tgl_ber.setText("tglber");

        jam_ber.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jam_ber.setText("jamber");

        tgl_tiba.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        tgl_tiba.setText("tgltib");

        jam_tiba.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jam_tiba.setText("jamber");

        bandara_asal.setBackground(new java.awt.Color(0, 0, 0));
        bandara_asal.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        bandara_asal.setText("bandara asal");

        kota_asal.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        kota_asal.setText("kota asal");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(kota_asal, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(bandara_asal, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(kota_asal, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bandara_asal, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel4Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {bandara_asal, kota_asal});

        kota_tujuan.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        kota_tujuan.setText("kota tujuan");

        bandara_tujuan.setBackground(new java.awt.Color(0, 0, 0));
        bandara_tujuan.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        bandara_tujuan.setText("bandaratujuan");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(kota_tujuan, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(bandara_tujuan, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel5Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {bandara_tujuan, kota_tujuan});

        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(kota_tujuan, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bandara_tujuan, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout panel_pesawatLayout = new javax.swing.GroupLayout(panel_pesawat);
        panel_pesawat.setLayout(panel_pesawatLayout);
        panel_pesawatLayout.setHorizontalGroup(
            panel_pesawatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_pesawatLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_pesawatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_pesawatLayout.createSequentialGroup()
                        .addGap(200, 200, 200)
                        .addGroup(panel_pesawatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jam_ber, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jam_tiba, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(tgl_ber, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tgl_tiba, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(kelas, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(maskapai, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panel_pesawatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(pesawat, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jenis, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 79, Short.MAX_VALUE)))
                .addContainerGap(113, Short.MAX_VALUE))
        );

        panel_pesawatLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jenis, kelas, maskapai});

        panel_pesawatLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jPanel4, jPanel5});

        panel_pesawatLayout.setVerticalGroup(
            panel_pesawatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_pesawatLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
                .addComponent(maskapai)
                .addGap(18, 18, 18)
                .addComponent(kelas)
                .addGap(18, 18, 18)
                .addComponent(jenis)
                .addGap(18, 18, 18)
                .addComponent(pesawat)
                .addGap(40, 40, 40)
                .addGroup(panel_pesawatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tgl_ber)
                    .addComponent(jam_ber))
                .addGap(18, 18, 18)
                .addGroup(panel_pesawatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tgl_tiba)
                    .addComponent(jam_tiba))
                .addGap(25, 25, 25))
        );

        panel_pesawatLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jenis, kelas, maskapai});

        jTabbedPane1.addTab("", panel_pesawat);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 60, 530, 500));
        jTabbedPane1.getAccessibleContext().setAccessibleName("");

        jLabel12.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Silahkan tekan tombol untuk menambah tiket!");

        pilih_data.setBackground(new java.awt.Color(0, 0, 0));
        pilih_data.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        pilih_data.setForeground(new java.awt.Color(255, 255, 255));
        pilih_data.setText("Pilih Data");
        pilih_data.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pilih_dataActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(126, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addComponent(pilih_data, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(115, 115, 115))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pilih_data)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 560, 530, 80));

        jLabel7.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel7.setText("Masukkan Harga Tiket");

        jLabel8.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel8.setText("Harga       :");

        jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextField1KeyTyped(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel9.setText("Rp.");

        jLabel10.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel10.setText("Harga per-1 buah tiket adalah");

        jButton2.setBackground(new java.awt.Color(255, 255, 255));
        jButton2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jButton2.setText("Simpan Harga");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        Hargato.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        Hargato.setText("         ");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(139, 139, 139)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Hargato, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel7)
                .addGap(35, 35, 35)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(26, 26, 26)
                .addComponent(jButton2)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(Hargato))
                .addContainerGap(28, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 30, 430, 220));

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jButton1.setText("Simpan Tiket");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(286, 215, 123, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel2.setText("Tiket akan di simpan dengan ID ");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel3.setText("selanjutnya, ");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(336, 90, 84, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel4.setText("setelah menekan tombol \"simpan tiket\", maka tiket akan ");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel5.setText("dapat di akses Oleh pembeli.");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 150, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI Semibold", 0, 24)); // NOI18N
        jLabel6.setText("PERHATIAN!");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(166, 20, 155, 28));

        tiketo.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jPanel2.add(tiketo, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 90, 90, 20));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 380, 430, 280));

        panel_pesawat_tab.setBackground(new java.awt.Color(0, 0, 0));

        tab11.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        tab11.setForeground(new java.awt.Color(255, 255, 255));
        tab11.setText("Asal");

        tab12.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        tab12.setForeground(new java.awt.Color(255, 255, 255));
        tab12.setText("Tujuan");

        tab13.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        tab13.setForeground(new java.awt.Color(255, 255, 255));
        tab13.setText("Maskapai");

        tab14.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        tab14.setForeground(new java.awt.Color(255, 255, 255));
        tab14.setText("Kelas");

        tab15.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        tab15.setForeground(new java.awt.Color(255, 255, 255));
        tab15.setText("Jenis");

        tab16.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        tab16.setForeground(new java.awt.Color(255, 255, 255));
        tab16.setText("Pesawat");

        tab17.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        tab17.setForeground(new java.awt.Color(255, 255, 255));
        tab17.setText("Berangkat");

        tab18.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        tab18.setForeground(new java.awt.Color(255, 255, 255));
        tab18.setText("Tiba");

        javax.swing.GroupLayout panel_pesawat_tabLayout = new javax.swing.GroupLayout(panel_pesawat_tab);
        panel_pesawat_tab.setLayout(panel_pesawat_tabLayout);
        panel_pesawat_tabLayout.setHorizontalGroup(
            panel_pesawat_tabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_pesawat_tabLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_pesawat_tabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_pesawat_tabLayout.createSequentialGroup()
                        .addGroup(panel_pesawat_tabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tab13, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tab15, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tab16, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tab14, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(tab17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panel_pesawat_tabLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(panel_pesawat_tabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tab11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tab12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(tab18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(30, 30, 30))
        );
        panel_pesawat_tabLayout.setVerticalGroup(
            panel_pesawat_tabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_pesawat_tabLayout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addComponent(tab11)
                .addGap(32, 32, 32)
                .addComponent(tab12)
                .addGap(64, 64, 64)
                .addComponent(tab13)
                .addGap(18, 18, 18)
                .addComponent(tab14)
                .addGap(18, 18, 18)
                .addComponent(tab15)
                .addGap(18, 18, 18)
                .addComponent(tab16)
                .addGap(43, 43, 43)
                .addComponent(tab17)
                .addGap(18, 18, 18)
                .addComponent(tab18)
                .addGap(29, 29, 29))
        );

        getContentPane().add(panel_pesawat_tab, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 80, 100, 480));

        jLabel11.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel11.setText("Jumlah Kursi Adalah ");

        jumlah_kursi.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jumlah_kursi.setText("Jumlah");

        javax.swing.GroupLayout panel_jumlahLayout = new javax.swing.GroupLayout(panel_jumlah);
        panel_jumlah.setLayout(panel_jumlahLayout);
        panel_jumlahLayout.setHorizontalGroup(
            panel_jumlahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_jumlahLayout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jumlah_kursi, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(161, Short.MAX_VALUE))
        );
        panel_jumlahLayout.setVerticalGroup(
            panel_jumlahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_jumlahLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(panel_jumlahLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(jumlah_kursi))
                .addContainerGap(30, Short.MAX_VALUE))
        );

        getContentPane().add(panel_jumlah, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 270, 430, 80));

        Login6.setBackground(new java.awt.Color(0, 0, 0));
        Login6.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        Login6.setForeground(new java.awt.Color(255, 255, 255));
        Login6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/utama/home-page.png"))); // NOI18N
        Login6.setBorder(null);
        Login6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Login6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addComponent(Login6, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Login6, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(680, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 120, 750));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/utama/s.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1360, 770));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void idotomatis(){
        String tiket = "tiket";
        Random acak = new Random();
        int a = 0;
        for (int i = 0; i < 1; i++) {
           a =  acak.nextInt(100000);
        }
        
        tiketo.setText(tiket + a);
    }
     
    
    void panggil(){
     try {
            String sql1 = "select * from pesawat where id_mesin  = '" + set_idmesin.getText() + "'";
            java.sql.Connection conn1 = (Connection) koneksi.configDB();
            java.sql.Statement stm1 = conn1.createStatement();
            java.sql.ResultSet res1 = stm1.executeQuery(sql1);
            if (res1.next()) {
              
             String sisa = res1.getString("nama_pesawat");
             pesawat.setText(sisa);
             
            }else{
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "GAGAL");

        }
         try {
            String sql1 = "select * from maskapai where id_maskapai  = '" + getIdmaskapai()+ "'";
            java.sql.Connection conn1 = (Connection) koneksi.configDB();
            java.sql.Statement stm1 = conn1.createStatement();
            java.sql.ResultSet res1 = stm1.executeQuery(sql1);
            if (res1.next()) {
              
             String sisa = res1.getString("nama_maskapai");
             maskapai.setText(sisa);
             
            }else{
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "GAGAL");

        }
    try {
            String sql1 = "select * from kelas where id_kelas  = '" + getIdkelas()+ "'";
            java.sql.Connection conn1 = (Connection) koneksi.configDB();
            java.sql.Statement stm1 = conn1.createStatement();
            java.sql.ResultSet res1 = stm1.executeQuery(sql1);
            if (res1.next()) {
              
             String sisa = res1.getString("nama_kelas");
             kelas.setText(sisa);
             String kapasitas = res1.getString("kapasitas");
             jumlah_kursi.setText(kapasitas);
            }else{
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "GAGAL");

        }
        try {
            String sql1 = "select * from jenis_penerbangan where id_jenis  = '" + getIdjenis()+ "'";
            java.sql.Connection conn1 = (Connection) koneksi.configDB();
            java.sql.Statement stm1 = conn1.createStatement();
            java.sql.ResultSet res1 = stm1.executeQuery(sql1);
            if (res1.next()) {
              
             String sisa = res1.getString("jenis_penerbangan");
             jenis.setText(sisa);
             
            }else{
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "GAGAL");

        }
   
    }
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try{
            
            java.sql.Connection conn=(Connection)koneksi.configDB();
            String sql = "Select * from tiket where id_penerbangan like '%" + set_idpenerbangan.getText() + "%'" +
            "and id_mesin like '%" + set_idmesin.getText() + "%'"  +
            "and id_jadwal like '%" + set_idjadwal.getText() + "%'";
            java.sql.Statement stm=conn.createStatement();
            java.sql.ResultSet res=stm.executeQuery(sql);
            if (res.next()) {
                
               JOptionPane.showMessageDialog(null, "Tiket Sudah Ada");
            }
            else{
                simpan();
                semuaData sd = new semuaData();
                this.dispose();
                    }    }catch(Exception ex){
            
               JOptionPane.showMessageDialog(null, ex.getMessage());
            }
                
       // semuaData sd = new semuaData();
       // sd.jTabbedPane1.setSelectedIndex(2);
       // sd.setVisible(true);
     //   this.setVisible(false);
       // sd.jButton3.setVisible(false);
        //sd.jButton1.setVisible(false);
            
        
    }//GEN-LAST:event_jButton1ActionPerformed

    void simpan(){
    if (tiketo.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(null, "Lengkapi Data");
        }
        String sql = "INSERT INTO tiket VALUES ('" + tiketo.getText() + "','" + set_idpenerbangan.getText() + "','" + set_idmesin.getText() + "','" + getIdmaskapai() + "','" + getIdkelas() + "','" + set_idjadwal.getText() + "','" + jTextField1.getText() + "','" + jumlah_kursi.getText() + "')";
        try {
            java.sql.Connection conn = (Connection) koneksi.configDB();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Penyimpanan Data Berhasil");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    
    }
    
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        panel_jumlah.setVisible(true);
        angka = Integer.parseInt(jTextField1.getText());
        ganti = NumberFormat.getNumberInstance(Locale.US).format(angka);
        token = new StringTokenizer(ganti, ".");
        ganti = token.nextToken();
        ganti = ganti.replace(',', '.');
        Hargato.setText("Rp. " + String.format(ganti));
        jPanel2.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jTextField1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField1KeyTyped
        char karakter = evt.getKeyChar();
        if (!(((karakter >= '0') && (karakter <= '9') || (karakter == KeyEvent.VK_BACK_SPACE) || (karakter == KeyEvent.VK_DELETE)))) {
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_jTextField1KeyTyped

    private void Login6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Login6ActionPerformed
        tiket_pesawat tp = new tiket_pesawat();
        tp.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_Login6ActionPerformed

    private void pilih_dataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pilih_dataActionPerformed
        if (jCheckBox1.isSelected() && jCheckBox2.isSelected() && jCheckBox3.isSelected()) {
            jTabbedPane1.setSelectedIndex(1);
            panggil();
            panel_pesawat_tab.setVisible(true);
            jPanel1.setVisible(false);
            jPanel3.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Lengkapi Data");
        }
        
    }//GEN-LAST:event_pilih_dataActionPerformed

    String idjenis, idmaskapai, idpesawat, idkelas;

    public String getIdjenis() {
        return idjenis;
    }

    public void setIdjenis(String idjenis) {
        this.idjenis = idjenis;
    }

    public String getIdmaskapai() {
        return idmaskapai;
    }

    public void setIdmaskapai(String idmaskapai) {
        this.idmaskapai = idmaskapai;
    }

    public String getIdkelas() {
        return idkelas;
    }

    public void setIdkelas(String idkelas) {
        this.idkelas = idkelas;
    }
    
    
    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        int baris = jTable1.rowAtPoint(evt.getPoint());
        String t1 = jTable1.getValueAt(baris, 1).toString();
        set_idmesin.setText(t1);
        String c1 = jTable1.getValueAt(baris, 2).toString();
        setIdmaskapai(c1);
        String c11 = jTable1.getValueAt(baris, 3).toString();
        setIdkelas(c11);
        jCheckBox1.setSelected(true);
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        int baris = jTable2.rowAtPoint(evt.getPoint());
        String a1 = jTable2.getValueAt(baris, 1).toString();
        set_idpenerbangan.setText(a1);
        String a2 = jTable2.getValueAt(baris, 2).toString();
        setIdjenis(a2);
        String a3 = jTable2.getValueAt(baris, 3).toString();
        kota_asal.setText(a3);
        String a4 = jTable2.getValueAt(baris, 4).toString();
        bandara_asal.setText(a4);
        String a5 = jTable2.getValueAt(baris, 5).toString();
        kota_tujuan.setText(a5);
        String a6 = jTable2.getValueAt(baris, 6).toString();
        bandara_tujuan.setText(a6);
        jCheckBox2.setSelected(true);
    }//GEN-LAST:event_jTable2MouseClicked

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseClicked
        int baris = jTable3.rowAtPoint(evt.getPoint());
        String t1 = jTable3.getValueAt(baris, 1).toString();
        set_idjadwal.setText(t1);
        String t2 = jTable3.getValueAt(baris, 2).toString();
        tgl_ber.setText(t2);
        String t3 = jTable3.getValueAt(baris, 3).toString();
        jam_ber.setText(t3);
        String t4 = jTable3.getValueAt(baris, 4).toString();
        tgl_tiba.setText(t4);
        String t5 = jTable3.getValueAt(baris, 5).toString();
        jam_tiba.setText(t5);
        jCheckBox3.setSelected(true);
    }//GEN-LAST:event_jTable3MouseClicked
public void lebarKolom1(){ 
        TableColumn column;
        jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF); 
        column = jTable1.getColumnModel().getColumn(0); 
        column.setPreferredWidth(25);
        column = jTable1.getColumnModel().getColumn(1); 
        column.setPreferredWidth(140); 
        column = jTable1.getColumnModel().getColumn(2); 
        column.setPreferredWidth(140); 
        column = jTable1.getColumnModel().getColumn(3); 
        column.setPreferredWidth(140); 
    }
public void lebarKolom2(){ 
        TableColumn column;
        jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF); 
        column = jTable2.getColumnModel().getColumn(0); 
        column.setPreferredWidth(25);
        column = jTable2.getColumnModel().getColumn(1); 
        column.setPreferredWidth(100); 
        column = jTable2.getColumnModel().getColumn(2); 
        column.setPreferredWidth(100); 
        column = jTable2.getColumnModel().getColumn(3); 
        column.setPreferredWidth(100); 
        column = jTable2.getColumnModel().getColumn(4); 
        column.setPreferredWidth(100);
        column = jTable2.getColumnModel().getColumn(5); 
        column.setPreferredWidth(100); 
        column = jTable2.getColumnModel().getColumn(6); 
        column.setPreferredWidth(100); 
    }
     private void load_table1(){
        // membuat tampilan model tabel
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("No Mesin");
        model.addColumn("ID Maskapai");
        model.addColumn("ID Kelas");

        //menampilkan data database kedalam tabel
        try {
            int no=1;
            String sql = "select * from detail_pesawat";
            java.sql.Connection conn=(Connection)koneksi.configDB();
            java.sql.Statement stm=conn.createStatement();
            java.sql.ResultSet res=stm.executeQuery(sql);
            while(res.next()){
                model.addRow(new Object[]{no++,res.getString(1),res.getString(2),res.getString(3)});
            }
            jTable1.setModel(model);
        } catch (Exception e) {
        }}
    
     private void load_table2(){
        // membuat tampilan model tabel
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("ID Penerbangan");
        model.addColumn("ID Jenis");
        model.addColumn("Kota Asal");
        model.addColumn("Bandara Asal");
        model.addColumn("Kota Tujuan");
        model.addColumn("Bandara Tujuan");
        
        //menampilkan data database kedalam tabel
        try {
            int no=1;
            String sql = "select * from penerbangan";
            java.sql.Connection conn=(Connection)koneksi.configDB();
            java.sql.Statement stm=conn.createStatement();
            java.sql.ResultSet res=stm.executeQuery(sql);
            while(res.next()){
                model.addRow(new Object[]{no++,res.getString(1),res.getString(2),res.getString(3),res.getString(4),res.getString(5),res.getString(6)});
            }
            jTable2.setModel(model);
        } catch (Exception e) {
        }}

    private void load_table3(){
        // membuat tampilan model tabel
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("ID Jawal");
        model.addColumn("Tanggal Berangkat");
        model.addColumn("Jam Berangkat");
        model.addColumn("Tanggal Tiba");
        model.addColumn("Jam Tiba");
        
        //menampilkan data database kedalam tabel
        
        try {
            int no=1;
            String sql = "select * from jadwal";
            java.sql.Connection conn=(Connection)koneksi.configDB();
            java.sql.Statement stm=conn.createStatement();
            java.sql.ResultSet res=stm.executeQuery(sql);
            while(res.next()){
                model.addRow(new Object[]{no++,res.getString(1),res.getString(2),res.getString(3),res.getString(4),res.getString(5)});
            }
            jTable3.setModel(model);
        } catch (Exception e) {
        }}
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(tiket_.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(tiket_.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(tiket_.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(tiket_.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new tiket_().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Hargato;
    private javax.swing.JButton Login6;
    public javax.swing.JLabel bandara_asal;
    public javax.swing.JLabel bandara_tujuan;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    public javax.swing.JPanel jPanel2;
    public javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextField jTextField1;
    public javax.swing.JLabel jam_ber;
    public javax.swing.JLabel jam_tiba;
    public javax.swing.JLabel jenis;
    public javax.swing.JLabel jumlah_kursi;
    public javax.swing.JLabel kelas;
    public javax.swing.JLabel kota_asal;
    public javax.swing.JLabel kota_tujuan;
    public javax.swing.JLabel maskapai;
    private javax.swing.JPanel panel_jumlah;
    private javax.swing.JPanel panel_pesawat;
    private javax.swing.JPanel panel_pesawat_tab;
    public javax.swing.JLabel pesawat;
    private javax.swing.JButton pilih_data;
    private javax.swing.JPanel pilih_penerbangan;
    public javax.swing.JLabel set_idjadwal;
    public javax.swing.JLabel set_idmesin;
    public javax.swing.JLabel set_idpenerbangan;
    public javax.swing.JLabel tab10;
    public javax.swing.JLabel tab11;
    public javax.swing.JLabel tab12;
    public javax.swing.JLabel tab13;
    public javax.swing.JLabel tab14;
    public javax.swing.JLabel tab15;
    public javax.swing.JLabel tab16;
    public javax.swing.JLabel tab17;
    public javax.swing.JLabel tab18;
    public javax.swing.JLabel tab8;
    public javax.swing.JLabel tab9;
    public javax.swing.JLabel tgl_ber;
    public javax.swing.JLabel tgl_tiba;
    private javax.swing.JLabel tiketo;
    // End of variables declaration//GEN-END:variables
}
