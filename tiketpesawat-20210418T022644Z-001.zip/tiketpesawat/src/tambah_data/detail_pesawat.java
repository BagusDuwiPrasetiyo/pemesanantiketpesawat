package tambah_data;

import admin.koneksi;
import java.awt.Color;
import java.sql.Connection;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class detail_pesawat extends javax.swing.JPanel {

    public detail_pesawat() {
        initComponents();
//    tampilCombo();
    load_table();
    load_table2();
    load_table3();
    desain();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        simpan = new javax.swing.JButton();
        tambah = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        a1 = new javax.swing.JLabel();
        a2 = new javax.swing.JLabel();
        a3 = new javax.swing.JLabel();
        a4 = new javax.swing.JLabel();
        a5 = new javax.swing.JLabel();
        a6 = new javax.swing.JLabel();
        Login = new javax.swing.JButton();
        Login1 = new javax.swing.JButton();
        Login3 = new javax.swing.JButton();
        Login8 = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));

        jTable1.setForeground(new java.awt.Color(255, 255, 255));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.setEnabled(false);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        simpan.setBackground(new java.awt.Color(255, 255, 255));
        simpan.setForeground(new java.awt.Color(255, 255, 255));
        simpan.setText("Simpan");
        simpan.setFocusable(false);
        simpan.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        simpan.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                simpanActionPerformed(evt);
            }
        });

        tambah.setBackground(new java.awt.Color(255, 255, 255));
        tambah.setForeground(new java.awt.Color(255, 255, 255));
        tambah.setText("Tambah");
        tambah.setFocusable(false);
        tambah.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        tambah.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        tambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambahActionPerformed(evt);
            }
        });

        jTable2.setForeground(new java.awt.Color(255, 255, 255));
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable2.setEnabled(false);
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable2);

        jTable3.setForeground(new java.awt.Color(255, 255, 255));
        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable3.setEnabled(false);
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable3);

        a1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        a1.setText("No Mesin");

        a2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        a2.setText("ID Maskapai");

        a3.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        a3.setText("ID Kelas");

        a4.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        a4.setText("Pesawat");

        a5.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        a5.setText("Maskapai");

        a6.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        a6.setText("Kelas");

        Login.setBackground(new java.awt.Color(102, 102, 102));
        Login.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        Login.setForeground(new java.awt.Color(255, 255, 255));
        Login.setText("Tambah Pesawat");
        Login.setBorder(null);
        Login.setFocusable(false);
        Login.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Login.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        Login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginActionPerformed(evt);
            }
        });

        Login1.setBackground(new java.awt.Color(102, 102, 102));
        Login1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        Login1.setForeground(new java.awt.Color(255, 255, 255));
        Login1.setText("Tambah Maskapai");
        Login1.setBorder(null);
        Login1.setFocusable(false);
        Login1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Login1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        Login1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Login1ActionPerformed(evt);
            }
        });

        Login3.setBackground(new java.awt.Color(102, 102, 102));
        Login3.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        Login3.setForeground(new java.awt.Color(255, 255, 255));
        Login3.setText("Tambah Kelas");
        Login3.setBorder(null);
        Login3.setFocusable(false);
        Login3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Login3.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        Login3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Login3ActionPerformed(evt);
            }
        });

        Login8.setBackground(new java.awt.Color(102, 102, 102));
        Login8.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        Login8.setForeground(new java.awt.Color(255, 255, 255));
        Login8.setText("Detail");
        Login8.setBorder(null);
        Login8.setFocusable(false);
        Login8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Login8.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        Login8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Login8ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 697, Short.MAX_VALUE)
                    .addComponent(jScrollPane2)
                    .addComponent(jScrollPane3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Login1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 144, Short.MAX_VALUE)
                    .addComponent(Login3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Login, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(a6)
                        .addGap(56, 56, 56)
                        .addComponent(a3))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(tambah, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(simpan, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(a4)
                                .addGap(38, 38, 38)
                                .addComponent(a1))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(a5)
                                .addGap(30, 30, 30)
                                .addComponent(a2)))
                        .addGap(13, 13, 13)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Login8, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(Login, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50)
                        .addComponent(Login1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(52, 52, 52)
                        .addComponent(Login3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(Login8, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(166, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(a4)
                            .addComponent(a1))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(a5)
                            .addComponent(a2))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(a6)
                            .addComponent(a3))
                        .addGap(16, 16, 16)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tambah)
                            .addComponent(simpan))
                        .addGap(69, 69, 69))))
        );

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {Login, Login1, Login3});

    }// </editor-fold>//GEN-END:initComponents
    
    private void bersih(){
    a1.setText("No Mesin");
    a2.setText("ID Maskapai");
    a3.setText("ID Kelas");
    }
     
    void desain(){
        simpan.setBackground(new Color(0,0,0,100));
Login8.setBackground(new Color(0, 0, 0, 100));
        jTable1.setBackground(new Color(0,0,0,100));
         jTable2.setBackground(new Color(0,0,0,100));
          jTable3.setBackground(new Color(0,0,0,100));
                      tambah.setBackground(new Color(0,0,0,100));  
       Login.setBackground(new Color(0,0,0,100));
       Login1.setBackground(new Color(0,0,0,100));
              Login3.setBackground(new Color(0,0,0,100));
    }
    
    private void simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_simpanActionPerformed
     if(a1.getText().equalsIgnoreCase("No Mesin"))  //Jika Nilai Yang diambil pada TxtNama Kosong ("")
        {
            JOptionPane.showMessageDialog(null,"Lengkapi Semua data"); //Tampilkan Nilai Pada Comand Dialog
        }if(a3.getText().equalsIgnoreCase("ID Kelas")){
            JOptionPane.showMessageDialog(null,"Lengkapi Semua data");
        }if(a2.getText().equalsIgnoreCase("ID Maskapai")){
            JOptionPane.showMessageDialog(null,"Lengkapi Semua data");
        }else{
        try {
            String sql = "INSERT INTO detail_pesawat VALUES ('"+a1.getText()+"','"+a2.getText()+"','"+a3.getText()+"')";
            java.sql.Connection conn=(Connection)koneksi.configDB();
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Penyimpanan Data Berhasil");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        }
        bersih();
        load_table();
        
    load_table2();
    load_table3();
    }//GEN-LAST:event_simpanActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        int baris = jTable1.rowAtPoint(evt.getPoint());
        String t1 = jTable1.getValueAt(baris, 1).toString();
        a1.setText(t1);

    }//GEN-LAST:event_jTable1MouseClicked

    private void tambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambahActionPerformed
        load_table();
            load_table2();
    load_table3();
        bersih();
    }//GEN-LAST:event_tambahActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        int baris = jTable2.rowAtPoint(evt.getPoint());
        String t1 = jTable2.getValueAt(baris, 1).toString();
        a2.setText(t1);
    }//GEN-LAST:event_jTable2MouseClicked

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseClicked
        int baris = jTable3.rowAtPoint(evt.getPoint());
        String t1 = jTable3.getValueAt(baris, 1).toString();
        a3.setText(t1);

    }//GEN-LAST:event_jTable3MouseClicked

    
    private void LoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginActionPerformed
        tiket_pesawat tp = new tiket_pesawat();
        tp.jPanel3.setVisible(true);
        tp.jTabbedPane2.setSelectedIndex(0);
tp.jTabbedPane3.setSelectedIndex(0);
    }//GEN-LAST:event_LoginActionPerformed

    private void Login1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Login1ActionPerformed
        tiket_pesawat tp = new tiket_pesawat();
        tp.jTabbedPane2.setSelectedIndex(1);
     tp.jPanel3.setVisible(true);
        tp.jTabbedPane3.setSelectedIndex(0);
    }//GEN-LAST:event_Login1ActionPerformed

    private void Login3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Login3ActionPerformed
        tiket_pesawat tp = new tiket_pesawat();
        tp.jPanel3.setVisible(true);
        tp.jTabbedPane2.setSelectedIndex(2);
        tp.jTabbedPane3.setSelectedIndex(0);
        // TODO add your handling code here:
    }//GEN-LAST:event_Login3ActionPerformed

    private void Login8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Login8ActionPerformed
        tiket_pesawat tp = new tiket_pesawat();
        tp.jTabbedPane2.setSelectedIndex(7);
        tp.jTabbedPane3.setSelectedIndex(0);
        tp.jPanel3.setVisible(true);
    }//GEN-LAST:event_Login8ActionPerformed
   
    private void load_table(){
        // membuat tampilan model tabel
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("ID Mesin");
        model.addColumn("Nama Pesawat");
        

        //menampilkan data database kedalam tabel
        try {
            int no=1;
            String sql = "select * from pesawat";
            java.sql.Connection conn=(Connection)koneksi.configDB();
            java.sql.Statement stm=conn.createStatement();
            java.sql.ResultSet res=stm.executeQuery(sql);
            while(res.next()){
                model.addRow(new Object[]{no++,res.getString(1),res.getString(2)});
            }
            jTable1.setModel(model);
        } catch (Exception e) {
        }}
    
    private void load_table2(){
        // membuat tampilan model tabel
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("ID Maskapai");
        model.addColumn("Nama Maskapai");
        

        //menampilkan data database kedalam tabel
        try {
            int no=1;
            String sql = "select * from maskapai";
            java.sql.Connection conn=(Connection)koneksi.configDB();
            java.sql.Statement stm=conn.createStatement();
            java.sql.ResultSet res=stm.executeQuery(sql);
            while(res.next()){
                model.addRow(new Object[]{no++,res.getString(1),res.getString(2)});
            }
            jTable2.setModel(model);
        } catch (Exception e) {
        }}
    
     private void load_table3(){
        // membuat tampilan model tabel
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("ID kelas");
        model.addColumn("Nama kelas");
        model.addColumn("Kapasitas");
        model.addColumn("fasilitas");
        

        //menampilkan data database kedalam tabel
        try {
            int no=1;
            String sql = "select * from kelas";
            java.sql.Connection conn=(Connection)koneksi.configDB();
            java.sql.Statement stm=conn.createStatement();
            java.sql.ResultSet res=stm.executeQuery(sql);
            while(res.next()){
                model.addRow(new Object[]{no++,res.getString(1),res.getString(2),res.getString(3),res.getString(4)});
            }
            jTable3.setModel(model);
        } catch (Exception e) {
        }}
   /*
     public void tampilCombo() {
        try
        {
            
            String sql = "select * from maskapai";
            java.sql.Connection conn=(Connection)koneksi.configDB();
            java.sql.Statement stm=conn.createStatement();
            java.sql.ResultSet res=stm.executeQuery(sql);
            jComboBox1.addItem("-Pilih Maskapai-");
            while(res.next())
            {
                jComboBox1.addItem(res.getString("nama_maskapai"));
            }
        }
        catch(Exception ex)
        {}
     try
        {
            
            String sql = "select * from kelas";
            java.sql.Connection conn=(Connection)koneksi.configDB();
            java.sql.Statement stm=conn.createStatement();
            java.sql.ResultSet res=stm.executeQuery(sql);
            jComboBox2.addItem("-Pilih kelas-");
            while(res.next())
            {
                jComboBox2.addItem(res.getString("nama_kelas"));
            }
        }
        catch(Exception ex)
        {}
     }
     */
    /*
    public void tampilText(){
    try
            {
                String sql = "select * from maskapai where nama_maskapai = '"+jComboBox1.getSelectedItem()+"'";
                java.sql.Connection conn=(Connection)koneksi.configDB();
                java.sql.Statement stm=conn.createStatement();
                java.sql.ResultSet res=stm.executeQuery(sql);
                while(res.next())
                {
                    jTextField2.setText(res.getString("id_maskapai"));
                }
            }catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"GAGAL");
            }
    
    }
    
    
*/
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Login;
    private javax.swing.JButton Login1;
    private javax.swing.JButton Login3;
    private javax.swing.JButton Login8;
    private javax.swing.JLabel a1;
    private javax.swing.JLabel a2;
    private javax.swing.JLabel a3;
    private javax.swing.JLabel a4;
    private javax.swing.JLabel a5;
    private javax.swing.JLabel a6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JButton simpan;
    private javax.swing.JButton tambah;
    // End of variables declaration//GEN-END:variables
}
