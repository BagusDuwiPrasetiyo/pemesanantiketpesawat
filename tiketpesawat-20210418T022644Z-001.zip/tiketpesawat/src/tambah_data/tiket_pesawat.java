package tambah_data;

import admin.koneksi;
import data_.semuaData;
import java.awt.Color;
import java.sql.Connection;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import tambah_tiket.tiket_;
import utama.tampil_utama;

/**
 *
 * @author LOrd
 */
public class tiket_pesawat extends javax.swing.JFrame {


    public tiket_pesawat() {
        initComponents();
        setExtendedState(getExtendedState()|JFrame.MAXIMIZED_BOTH);
        setVisible(true);
        jPanel3.setBackground(new Color(0,0,0,100));
        jTabbedPane2.setBackground(new Color(0,0,0,0));
        panel_jadwal1.setBackground(new Color(255,255,255,230));
        panel_kelas1.setBackground(new Color(255,255,255,230));
        panel_maskapai2.setBackground(new Color(255,255,255,230));
        panel_penerbangan1.setBackground(new Color(255,255,255,230));
        panel_pesawat1.setBackground(new Color(255,255,255,230));
       voucher1.setBackground(new Color(255,255,255,230));
       jPanel5.setBackground(new Color(255,255,255,230));
       jPanel6.setBackground(new Color(255,255,255,230));
       jTabbedPane3.setSelectedIndex(1);
       Login2.setBackground(new Color(0,0,0,100));
       jPanel1.setBackground(new Color(0,0,0,100));
       jPanel3.setVisible(false);
       jTabbedPane3.setBackground(new Color(0,0,0,0));
        Login4.setBackground(new Color(0, 0, 0, 100));
        Login5.setBackground(new Color(0, 0, 0, 100));
      //  Login6.setBackground(new Color(0, 0, 0, 100));
        Login7.setBackground(new Color(0, 0, 0, 100));
       // 
        edit.setBackground(new Color(0, 0, 0, 100));
        hapus.setBackground(new Color(0, 0, 0, 100));
        hapus1.setBackground(new Color(0, 0, 0, 100));
        tabel_detail.setBackground(new Color(255, 255, 255, 230));
        load_table();
        load_table1();
        load_table2();
        load_table3();
        load_table4();
        jTable1.setBackground(new Color(0, 0, 0, 200));
        jTable2.setBackground(new Color(0, 0, 0, 200));
        jTable3.setBackground(new Color(0, 0, 0, 200));
        jTable4.setBackground(new Color(0, 0, 0, 200));
        jTabbedPane1.setBackground(new Color(0, 0, 0, 0));
        jPanel2.setBackground(new Color(0, 0, 0, 200));
        jPanel3.setBackground(new Color(0, 0, 0, 200));
        jTabbedPane1.setVisible(false);
        jPanel2.setVisible(false);
        jTabbedPane2.setSelectedIndex(6);
        panel4();
    }

    private void bersih(){
    a1.setText("No Mesin");
    a2.setText("ID Maskapai");
    a3.setText("ID Kelas");
    }
    
    private void panel4(){
        jPanel4.setBackground(new Color(255,255,255,230));
        edit1.setBackground(new Color(0,0,0,100));
        hapus2.setBackground(new Color(0, 0, 0, 100));
        tambah.setBackground(new Color(0, 0, 0, 100));
        simpan.setBackground(new Color(0, 0, 0, 100));
        jTable5.setBackground(new Color(0, 0, 0, 200));

    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg_panel = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        Login2 = new javax.swing.JButton();
        Login7 = new javax.swing.JButton();
        Login4 = new javax.swing.JButton();
        Login5 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTabbedPane3 = new javax.swing.JTabbedPane();
        jPanel6 = new javax.swing.JPanel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        panel_pesawat1 = new tambah_data.panel_pesawat();
        panel_maskapai2 = new tambah_data.panel_maskapai();
        panel_kelas1 = new tambah_data.panel_kelas();
        panel_jadwal1 = new tambah_data.panel_jadwal();
        panel_penerbangan1 = new tambah_data.panel_penerbangan();
        voucher1 = new tambah_data.voucher();
        detail_pesawat1 = new tambah_data.detail_pesawat();
        tabel_detail = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel13 = new javax.swing.JLabel();
        a1 = new javax.swing.JLabel();
        a4 = new javax.swing.JLabel();
        a5 = new javax.swing.JLabel();
        a2 = new javax.swing.JLabel();
        a3 = new javax.swing.JLabel();
        a6 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        hapus = new javax.swing.JButton();
        edit = new javax.swing.JButton();
        hapus1 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        hapus2 = new javax.swing.JButton();
        edit1 = new javax.swing.JButton();
        simpan = new javax.swing.JButton();
        tambah = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        bg_panel.setBackground(new java.awt.Color(255, 255, 255));
        bg_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Login2.setBackground(new java.awt.Color(102, 102, 102));
        Login2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        Login2.setForeground(new java.awt.Color(255, 255, 255));
        Login2.setText("Penerbangan");
        Login2.setBorder(null);
        Login2.setFocusable(false);
        Login2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Login2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        Login2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Login2ActionPerformed(evt);
            }
        });
        jPanel3.add(Login2, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 0, 250, 50));

        Login7.setBackground(new java.awt.Color(102, 102, 102));
        Login7.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        Login7.setForeground(new java.awt.Color(255, 255, 255));
        Login7.setText("Pesawat");
        Login7.setBorder(null);
        Login7.setFocusable(false);
        Login7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Login7.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        Login7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Login7ActionPerformed(evt);
            }
        });
        jPanel3.add(Login7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 250, 50));

        Login4.setBackground(new java.awt.Color(102, 102, 102));
        Login4.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        Login4.setForeground(new java.awt.Color(255, 255, 255));
        Login4.setText("Jadwal");
        Login4.setBorder(null);
        Login4.setFocusable(false);
        Login4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Login4.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        Login4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Login4ActionPerformed(evt);
            }
        });
        jPanel3.add(Login4, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 0, 250, 50));

        Login5.setBackground(new java.awt.Color(102, 102, 102));
        Login5.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        Login5.setForeground(new java.awt.Color(255, 255, 255));
        Login5.setText("Voucher");
        Login5.setBorder(null);
        Login5.setFocusable(false);
        Login5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Login5.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        Login5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Login5ActionPerformed(evt);
            }
        });
        jPanel3.add(Login5, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 0, 250, 50));

        bg_panel.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 130, 1000, 50));

        jPanel1.setBackground(new java.awt.Color(102, 102, 102));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/utama/home-page.png"))); // NOI18N
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/utama/add-square-button.png"))); // NOI18N
        jLabel5.setText("Tambah Data");
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/utama/save.png"))); // NOI18N
        jLabel6.setText("Tambah Tiket");
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/utama/contract.png"))); // NOI18N
        jLabel8.setText("Laporan");
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/utama/rubbish-bin.png"))); // NOI18N
        jLabel9.setText("Hapus Tiket");
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/utama/exit.png"))); // NOI18N
        jLabel10.setText("Keluar");
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(jLabel4)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 10, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(102, 102, 102)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(jLabel9)
                .addGap(18, 18, 18)
                .addComponent(jLabel8)
                .addGap(80, 80, 80)
                .addComponent(jLabel10)
                .addContainerGap(275, Short.MAX_VALUE))
        );

        bg_panel.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 180, 760));

        jTabbedPane3.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        jTabbedPane3.setEnabled(false);

        jPanel6.setDoubleBuffered(false);
        jPanel6.setEnabled(false);
        jPanel6.setOpaque(false);

        jTabbedPane2.setBackground(new java.awt.Color(255, 255, 255));
        jTabbedPane2.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        jTabbedPane2.setEnabled(false);
        jTabbedPane2.setInheritsPopupMenu(true);
        jTabbedPane2.addTab("", panel_pesawat1);
        jTabbedPane2.addTab("", panel_maskapai2);
        jTabbedPane2.addTab("", panel_kelas1);
        jTabbedPane2.addTab("", panel_jadwal1);
        jTabbedPane2.addTab("", panel_penerbangan1);
        jTabbedPane2.addTab("", voucher1);
        jTabbedPane2.addTab("", detail_pesawat1);

        tabel_detail.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel12.setText("Silahkan pilih data yang akan di rubah!");
        tabel_detail.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 31, -1, -1));

        jTable1.setForeground(new java.awt.Color(255, 255, 255));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.setEnabled(false);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        tabel_detail.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 57, 610, 120));

        jLabel13.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel13.setText("Pilih dan rubah data!");
        tabel_detail.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 191, -1, -1));

        a1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        a1.setText("No Mesin");
        a1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                a1MouseClicked(evt);
            }
        });
        tabel_detail.add(a1, new org.netbeans.lib.awtextra.AbsoluteConstraints(99, 229, -1, -1));

        a4.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        a4.setText("Pesawat");
        tabel_detail.add(a4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 229, -1, -1));

        a5.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        a5.setText("Maskapai");
        tabel_detail.add(a5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 255, -1, -1));

        a2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        a2.setText("ID Maskapai");
        a2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                a2MouseClicked(evt);
            }
        });
        tabel_detail.add(a2, new org.netbeans.lib.awtextra.AbsoluteConstraints(99, 255, -1, -1));

        a3.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        a3.setText("ID Kelas");
        a3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                a3MouseClicked(evt);
            }
        });
        tabel_detail.add(a3, new org.netbeans.lib.awtextra.AbsoluteConstraints(99, 281, -1, -1));

        a6.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        a6.setText("Kelas");
        tabel_detail.add(a6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 281, -1, -1));

        jTabbedPane1.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        jTabbedPane1.setDoubleBuffered(true);
        jTabbedPane1.setEnabled(false);
        jTabbedPane1.setFocusCycleRoot(true);
        jTabbedPane1.setInheritsPopupMenu(true);

        jTable2.setForeground(new java.awt.Color(255, 255, 255));
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable2.setEnabled(false);
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable2);

        jTabbedPane1.addTab("", jScrollPane2);

        jTable4.setForeground(new java.awt.Color(255, 255, 255));
        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable4.setEnabled(false);
        jTable4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable4MouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(jTable4);

        jTabbedPane1.addTab("", jScrollPane4);

        jTable3.setForeground(new java.awt.Color(255, 255, 255));
        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable3.setEnabled(false);
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable3);

        jTabbedPane1.addTab("", jScrollPane3);

        tabel_detail.add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 220, 550, 200));
        jTabbedPane1.getAccessibleContext().setAccessibleName("");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 270, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        tabel_detail.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 230, 270, 20));

        hapus.setBackground(new java.awt.Color(255, 255, 255));
        hapus.setForeground(new java.awt.Color(255, 255, 255));
        hapus.setText("Hapus");
        hapus.setFocusable(false);
        hapus.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        hapus.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapusActionPerformed(evt);
            }
        });
        tabel_detail.add(hapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 340, 70, -1));

        edit.setBackground(new java.awt.Color(255, 255, 255));
        edit.setForeground(new java.awt.Color(255, 255, 255));
        edit.setText("Edit");
        edit.setFocusable(false);
        edit.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        edit.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editActionPerformed(evt);
            }
        });
        tabel_detail.add(edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, 70, -1));

        hapus1.setBackground(new java.awt.Color(255, 255, 255));
        hapus1.setForeground(new java.awt.Color(255, 255, 255));
        hapus1.setText("Reset");
        hapus1.setFocusable(false);
        hapus1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        hapus1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        hapus1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapus1ActionPerformed(evt);
            }
        });
        tabel_detail.add(hapus1, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 10, 70, -1));

        jTabbedPane2.addTab("", tabel_detail);

        jTable5.setForeground(new java.awt.Color(255, 255, 255));
        jTable5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable5.setEnabled(false);
        jTable5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable5MouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(jTable5);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("ID Jenis");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Nama Jenis");

        hapus2.setBackground(new java.awt.Color(255, 255, 255));
        hapus2.setForeground(new java.awt.Color(255, 255, 255));
        hapus2.setText("Hapus");
        hapus2.setFocusable(false);
        hapus2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        hapus2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        hapus2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapus2ActionPerformed(evt);
            }
        });

        edit1.setBackground(new java.awt.Color(255, 255, 255));
        edit1.setForeground(new java.awt.Color(255, 255, 255));
        edit1.setText("Edit");
        edit1.setFocusable(false);
        edit1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        edit1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        edit1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit1ActionPerformed(evt);
            }
        });

        simpan.setBackground(new java.awt.Color(255, 255, 255));
        simpan.setForeground(new java.awt.Color(255, 255, 255));
        simpan.setText("Simpan");
        simpan.setFocusable(false);
        simpan.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        simpan.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                simpanActionPerformed(evt);
            }
        });

        tambah.setBackground(new java.awt.Color(255, 255, 255));
        tambah.setForeground(new java.awt.Color(255, 255, 255));
        tambah.setText("Tambah");
        tambah.setFocusable(false);
        tambah.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        tambah.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        tambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambahActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(249, 249, 249)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(221, 221, 221)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(71, 71, 71)
                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(31, 31, 31)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(simpan, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(edit1, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(hapus2)
                            .addComponent(tambah, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(316, Short.MAX_VALUE))
        );

        jPanel4Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {edit1, hapus2, simpan, tambah});

        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(tambah, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(simpan, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(edit1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(hapus2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 121, Short.MAX_VALUE)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(127, 127, 127))
        );

        jPanel4Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {edit1, hapus2, simpan, tambah});

        jTabbedPane2.addTab("", jPanel4);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jTabbedPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 985, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 562, Short.MAX_VALUE)
        );

        jTabbedPane3.addTab("", jPanel6);

        jLabel7.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/utama/user.png"))); // NOI18N
        jLabel7.setText("Selamat Datang Admin!");

        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jTextArea1.setRows(5);
        jTextArea1.setText("Keterangan Fitur :\n1. Tambah Data, digunakan untuk menambah, mengganti dan menghapus \n    keseluruhan data awal, mulai dari pesawat, maskapai, kelas, jenis, \n    penerbangan, dan jadwal.\n2. Tambah Tiket, digunakan untuk menambah tiket baru dan tiket dapat di akses \n    setelah data di hapus.\n    Perhatian!!, tiket akan otomatis dihapus setelah sisa kursi = 0.\n3. Hapus Tiket, digunakan untuk menghapus tiket yang sudah terdaftar \n    sebelumnya.\n4. Laporan, digunakan untuk melihat transaksi user.");
        jScrollPane6.setViewportView(jTextArea1);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 512, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(61, 61, 61)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(66, 66, 66))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(215, 215, 215))))
        );

        jTabbedPane3.addTab("", jPanel5);

        bg_panel.add(jTabbedPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 120, 1000, 590));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/utama/s.jpg"))); // NOI18N
        bg_panel.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(4, -6, 1380, 770));

        jButton1.setText("jButton1");
        bg_panel.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 90, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg_panel, javax.swing.GroupLayout.PREFERRED_SIZE, 757, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(1380, 757));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void Login2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Login2ActionPerformed
        jTabbedPane2.setSelectedIndex(4);
    }//GEN-LAST:event_Login2ActionPerformed

    private void Login4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Login4ActionPerformed
        jTabbedPane2.setSelectedIndex(3);
    }//GEN-LAST:event_Login4ActionPerformed

    private void Login5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Login5ActionPerformed
        jTabbedPane2.setSelectedIndex(5);
    }//GEN-LAST:event_Login5ActionPerformed

    private void Login7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Login7ActionPerformed
        // TODO add your handling code here:
        jTabbedPane2.setSelectedIndex(6);
    }//GEN-LAST:event_Login7ActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        int baris = jTable2.rowAtPoint(evt.getPoint());
        String t1 = jTable2.getValueAt(baris, 1).toString();
        a1.setText(t1);
    }//GEN-LAST:event_jTable2MouseClicked

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseClicked
        int baris = jTable3.rowAtPoint(evt.getPoint());
        String t1 = jTable3.getValueAt(baris, 1).toString();
        a2.setText(t1);
    }//GEN-LAST:event_jTable3MouseClicked

    private void jTable4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable4MouseClicked
        int baris = jTable4.rowAtPoint(evt.getPoint());
        String t1 = jTable4.getValueAt(baris, 1).toString();
        a3.setText(t1);
    }//GEN-LAST:event_jTable4MouseClicked

    private void a1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_a1MouseClicked
        jTabbedPane1.setSelectedIndex(0);
        jTabbedPane1.setVisible(true);
        jPanel2.setVisible(true);
    }//GEN-LAST:event_a1MouseClicked

    private void a2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_a2MouseClicked
       jTabbedPane1.setSelectedIndex(2);
       jTabbedPane1.setVisible(true);
       jPanel2.setVisible(true);
    }//GEN-LAST:event_a2MouseClicked

    private void a3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_a3MouseClicked
        jTabbedPane1.setSelectedIndex(1);
        jTabbedPane1.setVisible(true);
        jPanel2.setVisible(true);
    }//GEN-LAST:event_a3MouseClicked

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        int baris = jTable1.rowAtPoint(evt.getPoint());
        String t1 = jTable1.getValueAt(baris, 1).toString();
        a1.setText(t1);
        String t2 = jTable1.getValueAt(baris, 2).toString();
        a2.setText(t2);
        String t3 = jTable1.getValueAt(baris, 3).toString();
        a3.setText(t3);
        jTabbedPane1.setVisible(true);
    }//GEN-LAST:event_jTable1MouseClicked

    private void hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapusActionPerformed
        // fungsi hapus data
        try {
            String sql = "delete from detail_pesawat where id_mesin = '" + a1.getText() + "'";
            java.sql.Connection conn = (Connection) koneksi.configDB();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(this, "berhasil di hapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        load_table1();
        bersih();

    }//GEN-LAST:event_hapusActionPerformed

    private void editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editActionPerformed
        if(a1.getText().equalsIgnoreCase("No Mesin"))  //Jika Nilai Yang diambil pada TxtNama Kosong ("")
        {
            JOptionPane.showMessageDialog(null,"Lengkapi Semua data"); //Tampilkan Nilai Pada Comand Dialog
        }if(a3.getText().equalsIgnoreCase("ID Kelas")){
            JOptionPane.showMessageDialog(null,"Lengkapi Semua data");
        }if(a2.getText().equalsIgnoreCase("ID Maskapai")){
            JOptionPane.showMessageDialog(null,"Lengkapi Semua data");
        }else{
            try {
                String sql ="UPDATE detail_pesawat SET id_maskapai =  '"+a2.getText()+"', id_kelas =  '"+a3.getText()+"' WHERE id_mesin = '"+a1.getText()+"'";
                java.sql.Connection conn=(Connection)koneksi.configDB();
                java.sql.PreparedStatement pst=conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null, "data berhasil di edit");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Perubahan Data Gagal"+e.getMessage());
            }}
            load_table1();
            bersih();
    }//GEN-LAST:event_editActionPerformed

    private void hapus1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapus1ActionPerformed
        bersih();
    }//GEN-LAST:event_hapus1ActionPerformed

    private void jTable5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable5MouseClicked
        int baris = jTable5.rowAtPoint(evt.getPoint());
        String t1 = jTable5.getValueAt(baris, 1).toString();
        jTextField1.setText(t1);
        String t2 = jTable5.getValueAt(baris, 2).toString();
        jTextField3.setText(t2);
    }//GEN-LAST:event_jTable5MouseClicked

    private void hapus2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapus2ActionPerformed
        // fungsi hapus data
        try {
            String sql ="delete from jenis_penerbangan where id_jenis = '"+jTextField1.getText()+"'";
            java.sql.Connection conn=(Connection)koneksi.configDB();
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(this, "berhasil di hapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        load_table4();
        bersih();
    }//GEN-LAST:event_hapus2ActionPerformed

    private void edit1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit1ActionPerformed
        if(jTextField1.getText().equalsIgnoreCase(""))  //Jika Nilai Yang diambil pada TxtNama Kosong ("")
        {
            JOptionPane.showMessageDialog(null,"Lengkapi Semua data"); //Tampilkan Nilai Pada Comand Dialog
        }else if(jTextField3.getText().equalsIgnoreCase("")){
            JOptionPane.showMessageDialog(null,"Lengkapi Semua data");
        }else{
            try {
                String sql ="UPDATE jenis_penerbangan SET jenis_penerbangan =  '"+jTextField3.getText()+"' WHERE id_jenis = '"+jTextField1.getText()+"'";
                java.sql.Connection conn=(Connection)koneksi.configDB();
                java.sql.PreparedStatement pst=conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null, "data berhasil di edit");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Perubahan Data Gagal"+e.getMessage());
            }}
            load_table4();
            bersih();
    }//GEN-LAST:event_edit1ActionPerformed

    private void simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_simpanActionPerformed
        if(jTextField1.getText().equalsIgnoreCase(""))  //Jika Nilai Yang diambil pada TxtNama Kosong ("")
        {
            JOptionPane.showMessageDialog(null,"Lengkapi Semua data"); //Tampilkan Nilai Pada Comand Dialog
        }if(jTextField3.getText().equalsIgnoreCase("")){
            JOptionPane.showMessageDialog(null,"Lengkapi Semua data");
        }else{
            try {
                String sql = "INSERT INTO jenis_penerbangan VALUES ('"+jTextField1.getText()+"','"+jTextField3.getText()+"')";
                java.sql.Connection conn=(Connection)koneksi.configDB();
                java.sql.PreparedStatement pst=conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null, "Penyimpanan Data Berhasil");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
        }
        bersih();
        load_table4();
    }//GEN-LAST:event_simpanActionPerformed

    private void tambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambahActionPerformed
        jTextField1.setText(null);
        jTextField3.setText(null);
        load_table();
        bersih();
    }//GEN-LAST:event_tambahActionPerformed

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
       jTabbedPane3.setSelectedIndex(0);
       jPanel3.setVisible(true);
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
       jTabbedPane3.setSelectedIndex(1);
       jPanel3.setVisible(false);
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        tiket_ t = new tiket_();
        this.dispose();
    }//GEN-LAST:event_jLabel6MouseClicked

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
    semuaData sd = new semuaData();
            sd.jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_jLabel8MouseClicked

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
        semuaData d = new semuaData();
        this.dispose();
    }//GEN-LAST:event_jLabel9MouseClicked

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
       tampil_utama tu = new tampil_utama();
       this.dispose();
    }//GEN-LAST:event_jLabel10MouseClicked
 
    private void load_table(){
        // membuat tampilan model tabel
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("ID Mesin");
        model.addColumn("Nama Pesawat");
        

        //menampilkan data database kedalam tabel
        try {
            int no=1;
            String sql = "select * from pesawat";
            java.sql.Connection conn=(Connection)koneksi.configDB();
            java.sql.Statement stm=conn.createStatement();
            java.sql.ResultSet res=stm.executeQuery(sql);
            while(res.next()){
                model.addRow(new Object[]{no++,res.getString(1),res.getString(2)});
            }
            jTable2.setModel(model);
        } catch (Exception e) {
        }}
    
    private void load_table1(){
        // membuat tampilan model tabel
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("No Mesin");
        model.addColumn("ID Maskapai");
        model.addColumn("ID Kelas");

        //menampilkan data database kedalam tabel
        try {
            int no=1;
            String sql = "select * from detail_pesawat";
            java.sql.Connection conn=(Connection)koneksi.configDB();
            java.sql.Statement stm=conn.createStatement();
            java.sql.ResultSet res=stm.executeQuery(sql);
            while(res.next()){
                model.addRow(new Object[]{no++,res.getString(1),res.getString(2),res.getString(3)});
            }
            jTable1.setModel(model);
        } catch (Exception e) {
        }}
    
    private void load_table2(){
        // membuat tampilan model tabel
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("ID Maskapai");
        model.addColumn("Nama Maskapai");
        

        //menampilkan data database kedalam tabel
        try {
            int no=1;
            String sql = "select * from maskapai";
            java.sql.Connection conn=(Connection)koneksi.configDB();
            java.sql.Statement stm=conn.createStatement();
            java.sql.ResultSet res=stm.executeQuery(sql);
            while(res.next()){
                model.addRow(new Object[]{no++,res.getString(1),res.getString(2)});
            }
            jTable3.setModel(model);
        } catch (Exception e) {
        }}
    
     private void load_table3(){
        // membuat tampilan model tabel
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("ID kelas");
        model.addColumn("Nama kelas");
        model.addColumn("Kapasitas");
        model.addColumn("fasilitas");
        

        //menampilkan data database kedalam tabel
        try {
            int no=1;
            String sql = "select * from kelas";
            java.sql.Connection conn=(Connection)koneksi.configDB();
            java.sql.Statement stm=conn.createStatement();
            java.sql.ResultSet res=stm.executeQuery(sql);
            while(res.next()){
                model.addRow(new Object[]{no++,res.getString(1),res.getString(2),res.getString(3),res.getString(4)});
            }
            jTable4.setModel(model);
        } catch (Exception e) {
        }}
    private void load_table4(){
        // membuat tampilan model tabel
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("ID Jenis");
        model.addColumn("Nama Jenis");
        

        //menampilkan data database kedalam tabel
        try {
            int no=1;
            String sql = "select * from jenis_penerbangan";
            java.sql.Connection conn=(Connection)koneksi.configDB();
            java.sql.Statement stm=conn.createStatement();
            java.sql.ResultSet res=stm.executeQuery(sql);
            while(res.next()){
                model.addRow(new Object[]{no++,res.getString(1),res.getString(2)});
            }
            jTable5.setModel(model);
        } catch (Exception e) {
        }}
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(tiket_pesawat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(tiket_pesawat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(tiket_pesawat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(tiket_pesawat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new tiket_pesawat().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Login2;
    private javax.swing.JButton Login4;
    private javax.swing.JButton Login5;
    private javax.swing.JButton Login7;
    private javax.swing.JLabel a1;
    private javax.swing.JLabel a2;
    private javax.swing.JLabel a3;
    private javax.swing.JLabel a4;
    private javax.swing.JLabel a5;
    private javax.swing.JLabel a6;
    private javax.swing.JPanel bg_panel;
    private tambah_data.detail_pesawat detail_pesawat1;
    private javax.swing.JButton edit;
    private javax.swing.JButton edit1;
    private javax.swing.JButton hapus;
    private javax.swing.JButton hapus1;
    private javax.swing.JButton hapus2;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    public javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTabbedPane jTabbedPane1;
    public javax.swing.JTabbedPane jTabbedPane2;
    public javax.swing.JTabbedPane jTabbedPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTable jTable5;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField3;
    private tambah_data.panel_jadwal panel_jadwal1;
    private tambah_data.panel_kelas panel_kelas1;
    private tambah_data.panel_maskapai panel_maskapai2;
    private tambah_data.panel_penerbangan panel_penerbangan1;
    private tambah_data.panel_pesawat panel_pesawat1;
    private javax.swing.JButton simpan;
    private javax.swing.JPanel tabel_detail;
    private javax.swing.JButton tambah;
    private tambah_data.voucher voucher1;
    // End of variables declaration//GEN-END:variables
}
